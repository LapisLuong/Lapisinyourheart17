# GIOI_THIEU_NGANH_Nhom06_13slide.pptx

## ppt/slides/slide1.xml

Giới thiệu ngành Công nghệ thông tin

Hệ thống hỗ trợ giám sát và cảnh báo té ngã bằng camera

Nhóm 06

 – Lớp IE005.R11.CNVN

Giảng viên: TS. Nguyễn Tấn Hoàng Phước

Trường Đại học Công nghệ Thông tin – ĐHQG-HCM

Hình minh họa do nhóm biên soạn

## ppt/slides/slide2.xml

Bối cảnh và vấn đề

684.000

ca tử vong do té ngã 

mỗi năm trên toàn thế giới

WHO, 2021 [1]

80%

30%

không tự đứng dậy sau ít nhất một lần ngã

từng nằm trên sàn từ một giờ trở lên

Trong 66 người trên 90 tuổi đã ngã [2]

Vấn đề:

 phát hiện sớm người đã ngã và nằm bất động.

[1] WHO, Falls, 2021.  [2] Fleming & Brayne, BMJ 337:a2227, 2008.

2

## ppt/slides/slide3.xml

Mục tiêu và phạm vi

Hỗ trợ giám sát

té ngã

Quan sát bằng camera

Một camera, chạy trong trình duyệt

Nhận biết dấu hiệu bất thường

Pha ngã, nằm bất động sau ngã

Tổ chức phản hồi trên giao diện

Cảnh báo tại chỗ, nút “Tôi ổn”

Phạm vi:

 nguyên mẫu học tập, không thay thế chẩn đoán y khoa.

3

## ppt/slides/slide4.xml

Nguyên lý hoạt động tổng quan

Tình huống: một người cao tuổi bị ngã trong phòng khách

1

Camera

Ghi hình khu vực sinh hoạt

2

Nhận biết tư thế

Xác định vai, hông, gối, cổ chân

3

Phân tích diễn biến

Thân chuyển nhanh từ đứng sang nằm

4

Giao diện phản hồi

Nằm bất động sau ngã thì cảnh báo

Sơ đồ minh họa do nhóm biên soạn

Luồng xử lý theo báo cáo FINAL 4, mục 2 và 3.

4

## ppt/slides/slide5.xml

Giao diện và cách sử dụng

Giao diện minh họa

1

2

3

4

5

1

Khung camera

: hình trực tiếp

2

Khung xương

: các điểm mốc

3

ID

: mã của từng người

4

Fall Score

: điểm quy tắc, 0 đến 1

5

Trạng thái

: mỗi người một trạng thái

.

5

## ppt/slides/slide6.xml

Cảnh báo và phản hồi

Nhận diện pha ngã

Chuyển sang FALLEN

Theo dõi bất động

Tích lũy đủ 15 s

Hiển thị cảnh báo

Còi, giọng nói, hộp thoại

Tiếp nhận phản hồi

“Tôi ổn” hoặc mở trình quay số

15 s bất động tích lũy

15 s đếm ngược hộp thoại

Hai mốc 15 s khác nhau, nối tiếp nhau

“Tôi ổn”

: hủy cảnh báo, quay về theo dõi.

Trình quay số

 chỉ mở sẵn, chưa phải cuộc gọi. 

Test Alert

 chỉ là mô phỏng.

.

6

## ppt/slides/slide7.xml

Mô hình ước lượng tư thế

Vai

Hông

Gối

Cổ chân

Minh họa một số điểm mốc

MediaPipe Pose Landmarker

 trả về 

33 điểm mốc

 cho mỗi khung hình, kèm độ hiển thị.

MediaPipe cho biết tư thế.

Quy tắc và máy trạng thái mới quyết định có té ngã hay không.

7

## ppt/slides/slide8.xml

Kiểm tra dữ liệu và theo dõi đối tượng

Không có tư thế hợp lệ

Không thấy người

Chưa đủ điều kiện

Thiếu vai và hông

Đủ điều kiện

Vai, hông rõ, thấy chân

ID

 nối cùng một người qua các bước; có thể đổi khi hai người đi cắt nhau.

8

## ppt/slides/slide9.xml

Fall Score hình thành như thế nào?

Chuẩn hóa

Nhân trọng số

Cộng lại

Hệ số vùng quan tâm

Giới hạn 0–1

Bảy thành phần và trọng số

Vận tốc dọc

0,22

Góc thân

0,20

Giảm chiều cao

0,18

Đầu thấp hơn hông

0,12

Tư thế ngang

0,12

Hạ thấp kéo dài

0,08

Điểm gần đáy khung

0,08

≤ 25°: bằng 0

≥ 70°: bằng 1

Thành phần góc thân (minh họa)

Không phải xác suất:

 0,68 không phải 68%.

9

## ppt/slides/slide10.xml

Máy trạng thái

Thiếu dữ liệu: chưa đánh giá ngã

NO_PERSON, PARTIAL_POSE

Bình thường

STANDING

Dấu hiệu ngã

PRE_FALL

Đã ngã

FALLEN

Cảnh báo

ALERT

Hạ nhanh, thân nghiêng

hoặc điểm ≥ 0,45

Nằm ngang 4 bước

hoặc điểm ≥ 0,68

Bất động tích lũy 15 s

Hồi phục: thân thẳng, đủ chiều cao; hoặc bấm “Tôi ổn”

Bộ đếm theo 

bước xử lý

, không theo giây. Chỉ xét bất động 

sau khi đã ngã

.

10

## ppt/notesSlides/notesSlide1.xml

THÔNG ĐIỆP CHÍNH: Nhóm 06 giới thiệu một nguyên mẫu ứng dụng web dùng camera để hỗ trợ giám sát và cảnh báo té ngã.

GIẢI THÍCH THÊM: Đây là sản phẩm học tập, không phải thiết bị y tế. Hình bìa là hình minh họa do nhóm biên soạn: một camera quan sát một người trong không gian sinh hoạt.

CÂU CHUYỂN Ý: Vì sao té ngã lại là vấn đề cần một hệ thống hỗ trợ như vậy? Nhóm em bắt đầu từ bối cảnh.

NGUỒN: Thông tin lớp, nhóm, giảng viên theo trang đầu báo cáo "NỘI DUNG GIỚI THIỆU NGÀNH FINAL 4".

KẾ HOẠCH HIỆU ỨNG: Chuyển trang Fade 0,30 s. Hình minh họa và chú thích Fade 0,20 s, tự chạy sau khi vào trang (không cần bấm). Tiêu đề hiện sẵn.

## ppt/notesSlides/notesSlide2.xml

THÔNG ĐIỆP CHÍNH: Té ngã là gánh nặng lớn, và hậu quả nặng hơn khi người ngã không tự đứng dậy và không ai biết.

GIẢI THÍCH THÊM:

- 684.000 là số ca TỬ VONG do té ngã mỗi năm trên toàn thế giới theo fact sheet của WHO năm 2021. Không đọc thành "số người bị ngã".

- 80% và 30% đến từ một nghiên cứu đoàn hệ trên người TRÊN 90 TUỔI ở Cambridge: 110 người tham gia, 66 người đã ngã. Trong 66 người đó, 80% (53/66) không tự đứng dậy được sau ít nhất một lần ngã; 30% (20/66) từng nằm trên sàn từ một giờ trở lên. Không khái quát hai con số này cho mọi lứa tuổi.

- Lưu ý: ngày 21/10/2026 WHO đã cập nhật fact sheet, ước tính khoảng 842.000 ca tử vong do té ngã năm 2023. Nhóm cần quyết định giữ số liệu 2021 (như báo cáo) hay cập nhật.

CÂU CHUYỂN Ý: Từ vấn đề đó, nhóm đặt mục tiêu và giới hạn phạm vi của đề tài.

NGUỒN:

[1] World Health Organization, "Falls," Fact sheet, 26/4/2021. https://www.who.int/news-room/fact-sheets/detail/falls

[2] J. Fleming and C. Brayne, "Inability to get up after falling, subsequent time on floor, and summoning help: prospective cohort study in people over 90," BMJ, vol. 337, a2227, 2008, doi: 10.1136/bmj.a2227. (Đã đối chiếu tóm tắt trên trang BMJ.)

KẾ HOẠCH HIỆU ỨNG: Chuyển trang Fade 0,30 s. Bấm 1: thẻ 684.000 (Fade 0,20 s). Bấm 2: thẻ 80% và 30% (Fade 0,20 s). Bấm 3: dải "Vấn đề" (Fade 0,20 s).

## ppt/notesSlides/notesSlide3.xml

THÔNG ĐIỆP CHÍNH: Mục tiêu là HỖ TRỢ giám sát té ngã bằng ba việc: quan sát bằng camera, nhận biết dấu hiệu bất thường, và tổ chức phản hồi trên giao diện.

GIẢI THÍCH THÊM: Theo FINAL 4, vấn đề đặt ra gồm: (i) nhận ra người đã ngã và nằm bất động; (ii) không kết luận ngã khi người đó chỉ cúi, ngồi hoặc camera chỉ thấy một phần cơ thể; (iii) cảnh báo tại chỗ và báo người chăm sóc khi không có phản hồi. Phạm vi: chỉ giám sát té ngã; không dự đoán cú ngã trước khi xảy ra, không chẩn đoán bệnh lý, không tự gọi cấp cứu khi chưa có xác nhận của con người. Ứng dụng là sản phẩm học tập, không phải thiết bị y tế.

CÂU CHUYỂN Ý: Vậy ba việc này nối với nhau như thế nào? Nhóm em đi qua nguyên lý tổng quan với một tình huống cụ thể.

NGUỒN: Báo cáo FINAL 4, mục 1 (Vấn đề đặt ra, Phạm vi). Sơ đồ minh họa do nhóm biên soạn.

KẾ HOẠCH HIỆU ỨNG: Chuyển trang Fade 0,30 s. Bấm 1: nút trung tâm (Fade 0,20 s). Bấm 2: ba nhánh, đường nối Wipe 0,25 s, ô nhánh Fade 0,20 s. Bấm 3: ô phạm vi (Fade 0,20 s).

## ppt/notesSlides/notesSlide4.xml

THÔNG ĐIỆP CHÍNH: Hệ thống đi qua bốn bước: camera, nhận biết tư thế, phân tích diễn biến qua nhiều khung hình, và giao diện phản hồi.

GIẢI THÍCH THÊM (tình huống xuyên suốt): Một người cao tuổi đi trong phòng khách. Camera ghi hình. Mô hình tư thế xác định các điểm mốc như vai, hông, gối, cổ chân. Một khung hình không đủ phân biệt "đang ngã" với "cúi nhặt đồ", nên ứng dụng theo dõi chuỗi pha: bình thường, hạ thấp nhanh, gần nằm ngang, rồi đứng dậy hoặc nằm yên. Nếu người đó nằm bất động sau pha ngã, giao diện mới chuyển sang cảnh báo. Slide này cố ý không có công thức; chi tiết nằm ở các slide 7 đến 10.

CÂU CHUYỂN Ý: Trước khi vào bên trong, nhóm em giới thiệu người dùng nhìn thấy gì trên màn hình.

NGUỒN: FINAL 4, mục 2.3 và 3.1. Biểu tượng là sơ đồ minh họa do nhóm biên soạn.

KẾ HOẠCH HIỆU ỨNG: Chuyển trang Fade 0,30 s. Bấm 1: bước 1 và 2 cùng mũi tên nối (Fade 0,20 s; mũi tên Wipe 0,25 s). Bấm 2: bước 3. Bấm 3: bước 4.

## ppt/notesSlides/notesSlide5.xml

THÔNG ĐIỆP CHÍNH: Màn hình giám sát cho thấy năm thông tin: khung camera, khung xương, ID của người, Fall Score và trạng thái hiện tại.

GIẢI THÍCH THÊM:

- Hình trên slide là GIAO DIỆN MINH HỌA do nhóm vẽ lại, không phải ảnh chụp ứng dụng. Nếu có ảnh chụp thật, thay vào cùng vị trí, giữ 5 chú thích, và ghi phiên bản cùng ngày chụp dưới ảnh.

- Mỗi người chỉ có MỘT trạng thái tại một thời điểm (ví dụ STANDING). Không hiển thị đồng thời STANDING và PRE_FALL.

- Fall Score là điểm theo quy tắc trong khoảng 0 đến 1, không phải xác suất (giải thích ở slide 9).

- Slide không mô tả nút bấm hay chức năng nào ngoài năm thành phần trên để tránh bịa tính năng.

CÂU CHUYỂN Ý: Khi trạng thái chuyển sang nguy hiểm, giao diện phản hồi theo trình tự nào? Đó là phần cảnh báo.

NGUỒN: FINAL 4, mục 3.2 (cổng kiểm tra, bộ theo dõi, Fall Score) và Bảng 1. Giao diện minh họa do nhóm biên soạn.

KẾ HOẠCH HIỆU ỨNG: Chuyển trang Fade 0,30 s. Bấm 1: hình giao diện (Fade 0,20 s). Bấm 2: chú thích 1 đến 3. Bấm 3: chú thích 4 và 5.

## ppt/notesSlides/notesSlide6.xml

THÔNG ĐIỆP CHÍNH: Cảnh báo đi theo bốn bước, và có hai mốc 15 giây khác nhau.

GIẢI THÍCH THÊM:

- Mốc 15 s thứ nhất nằm trong máy trạng thái: sau khi đã ở FALLEN, thời gian bất động (dịch chuyển tâm cơ thể dưới 0,015 mỗi bước) phải TÍCH LŨY đủ 15 s thì mới sang ALERT. Đây là thời gian tích lũy, không phải 15 giây liên tục: một cử động nhỏ chỉ trừ 0,2 s.

- Mốc 15 s thứ hai là đếm ngược của hộp thoại sau khi đã ALERT: còi, giọng nói tiếng Việt và hộp thoại có nút “Tôi ổn”.

- Vì hai mốc nối tiếp, từ FALLEN đến bước cuối mất ít nhất khoảng 30 s.

- Bấm “Tôi ổn”: cảnh báo bị hủy, trạng thái về STANDING.

- Nếu không có phản hồi: ứng dụng mở trình quay số tới người liên hệ ưu tiên. Mở trình quay số KHÔNG có nghĩa là cuộc gọi đã thành công; theo RFC 3966, trang web không được tự thực hiện cuộc gọi khi chưa có sự đồng ý của người dùng. Liên kết 115/112 do người dùng tự bấm.

- Test Alert chỉ mô phỏng luồng cảnh báo để trình diễn, không dùng để chứng minh khả năng phát hiện.

CÂU CHUYỂN Ý: Toàn bộ chuỗi này bắt đầu từ việc nhận biết tư thế. Nhóm em đi vào mô hình ước lượng tư thế.

NGUỒN: FINAL 4, mục 2.3, Bảng 1 và ba điểm cần hiểu đúng sau Bảng 1. [11] H. Schulzrinne, "The tel URI for telephone numbers," RFC 3966, IETF, 2004 (dẫn theo FINAL 4).

KẾ HOẠCH HIỆU ỨNG: Chuyển trang Fade 0,30 s. Bấm 1: bước 1, 2 và thanh 15 s thứ nhất. Bấm 2: bước 3, 4, thanh 15 s thứ hai và dòng giải thích (mũi tên Wipe 0,25 s, ô Fade 0,20 s). Bấm 3: hai ô chú thích. Không chạy đồng hồ đếm 15 s thật trên slide.

## ppt/notesSlides/notesSlide7.xml

THÔNG ĐIỆP CHÍNH: MediaPipe Pose Landmarker chỉ cung cấp tư thế (33 điểm mốc); việc quyết định té ngã do quy tắc và máy trạng thái của nhóm đảm nhận.

GIẢI THÍCH THÊM:

- MediaPipe Pose Landmarker là một biến thể của BlazePose, trả về 33 điểm mốc. Mỗi điểm có tọa độ chuẩn hóa x, y trong khoảng [0, 1] theo kích thước ảnh và độ hiển thị visibility trong [0, 1]. Gốc tọa độ ở góc trên bên trái, y tăng khi đi xuống.

- Vì tọa độ chuẩn hóa, ngưỡng "0,015" nghĩa là 1,5% kích thước khung hình, không phải 1,5 cm.

- Hình chỉ minh họa một số điểm mốc dùng nhiều trong đề tài: vai (11, 12), hông (23, 24), gối (25, 26), cổ chân (27, 28). Vị trí trong hình không phải tọa độ đo thật.

- Hình không ghi tọa độ cụ thể và không nêu thông số camera.

CÂU CHUYỂN Ý: Nhưng không phải khung hình nào cũng đủ tin cậy để đánh giá. Bước tiếp theo là kiểm tra dữ liệu đầu vào.

NGUỒN:

[5] Google AI Edge, "Pose landmark detection guide," MediaPipe Solutions. https://ai.google.dev/edge/mediapipe/solutions/vision/pose_landmarker

[6] V. Bazarevsky et al., "BlazePose: On-device real-time body pose tracking," arXiv:2006.10204, 2020.

[7] Google AI Edge, "Pose landmark detection guide for Web." (Dẫn theo FINAL 4, mục 2.1.)

KẾ HOẠCH HIỆU ỨNG: Chuyển trang Fade 0,30 s. Bấm 1: hình và nhãn (đường dẫn nhãn Wipe 0,25 s, chữ Fade 0,20 s). Bấm 2: đoạn mô tả. Bấm 3: ô thông điệp.

## ppt/notesSlides/notesSlide8.xml

THÔNG ĐIỆP CHÍNH: Ứng dụng chỉ đánh giá té ngã khi dữ liệu tư thế đủ tin cậy; vai và hông là quan trọng, nhưng không bắt buộc thấy đủ mọi bộ phận.

GIẢI THÍCH THÊM (điều kiện chi tiết theo FINAL 4):

- Điểm mốc chia bốn nhóm: đầu, thân (vai, hông), tay, chân. Một điểm được coi là "nhìn thấy" khi visibility ≥ 0,3.

- Tư thế bị loại khi có dưới 17 điểm, chỉ thấy mặt, chỉ thấy chân, hoặc thân có kích thước bất thường.

- Thân tin cậy khi có đủ điểm vai và hông, với visibility trung bình ≥ 0,4.

- Chỉ đánh giá ngã khi thân tin cậy VÀ (thấy chân HOẶC đủ 4 điểm thân). Không bắt buộc đủ cả bốn nhóm.

- Trạng thái tương ứng: không thấy người là NO_PERSON; thấy một phần là PARTIAL_POSE. Đây là chất lượng đầu vào, không phải mức nguy hiểm.

- Bộ theo dõi ghép mỗi tư thế với vết có tâm gần nhất (bán kính 0,38 theo tỷ lệ khung hình); vết được xác nhận sau 2 khung hợp lệ và bị xóa sau 3 s mất dấu. ID có thể đổi khi hai người đi cắt nhau.

CÂU CHUYỂN Ý: Khi dữ liệu đã đủ điều kiện, ứng dụng gộp các tín hiệu chuyển động thành một điểm gọi là Fall Score.

NGUỒN: FINAL 4, mục 3.2. Ba hình là sơ đồ minh họa do nhóm biên soạn.

KẾ HOẠCH HIỆU ỨNG: Chuyển trang Fade 0,30 s. Bấm 1: hình thứ nhất. Bấm 2: hình thứ hai và ba. Bấm 3: dải ID. Tất cả Fade 0,20 s.

## ppt/notesSlides/notesSlide9.xml

THÔNG ĐIỆP CHÍNH: Fall Score là điểm theo quy tắc, gộp bảy tín hiệu chuyển động thành một số từ 0 đến 1. Đây KHÔNG phải xác suất.

GIẢI THÍCH THÊM:

- Công thức đầy đủ: FallScore = clamp( m_ROI × Σ (i = 1..7) w_i × s_i ), trong đó mỗi thành phần s_i đã chuẩn hóa về [0, 1], m_ROI là hệ số vùng quan tâm, và clamp giới hạn kết quả về [0, 1].

- Trọng số (tổng bằng 1): vận tốc dọc 0,22; góc thân 0,20; giảm chiều cao 0,18; đầu thấp hơn hông 0,12; tư thế ngang 0,12; hạ thấp kéo dài 0,08; điểm gần đáy khung 0,08.

- Ví dụ góc thân: s_θ = clamp((θ − 25) / 45). θ là góc giữa đoạn vai–hông và phương thẳng đứng (0° khi đứng, 90° khi nằm). s_θ = 0 khi θ ≤ 25°, = 1 khi θ ≥ 70°, ở giữa tăng tuyến tính; ví dụ θ = 47,5° cho s_θ = 0,5.

- Các đại lượng phụ: tâm cơ thể C = 0,45 S + 0,55 H (S, H là trung điểm hai vai, hai hông); vận tốc dọc v_y = (C_y(t) − C_y(t−1)) / Δt, đơn vị chiều cao khung hình mỗi giây, dương khi đi xuống.

- "Điểm gần đáy khung" đếm các điểm có y > 0,78, tức gần mép dưới ẢNH. Không có nghĩa là người đã chạm sàn.

- Fall Score 0,68 chỉ là ngưỡng quy tắc, không phải 68% khả năng ngã.

CÂU CHUYỂN Ý: Một điểm số ở một thời điểm vẫn chưa đủ. Máy trạng thái mới là phần theo dõi diễn biến theo thời gian.

NGUỒN: FINAL 4, mục 2.1 (công thức 1–3) và mục 3.2 (công thức 4, trọng số, ví dụ s_θ).

KẾ HOẠCH HIỆU ỨNG: Chuyển trang Fade 0,30 s. Bấm 1: chuỗi gộp điểm (ô Fade 0,20 s, mũi tên Wipe 0,25 s). Bấm 2: bảng trọng số. Bấm 3: minh họa góc thân và ô "Không phải xác suất".

## ppt/notesSlides/notesSlide10.xml

THÔNG ĐIỆP CHÍNH: Máy trạng thái chỉ leo thang khi bằng chứng tích lũy qua nhiều bước, và hạ thang khi người dùng hồi phục. Chỉ bất động SAU NGÃ mới dẫn tới cảnh báo.

GIẢI THÍCH THÊM (điều kiện đầy đủ theo FINAL 4, Bảng 1):

- STANDING sang PRE_FALL: (v_y > 0,9 VÀ θ > 35°) HOẶC Fall Score ≥ 0,45 tích lũy 3 bước; yêu cầu người đã được xác nhận và thân tin cậy.

- PRE_FALL sang FALLEN: tư thế ngang (θ > 50° HOẶC tỷ lệ khung bao A > 1,15 HOẶC ≥ 3 điểm gần đáy) tích lũy 4 bước; HOẶC (Fall Score ≥ 0,68 VÀ θ > 60°); HOẶC hạ chiều cao nhanh.

- FALLEN sang ALERT: bất động (dịch chuyển tâm d < 0,015 mỗi bước) tích lũy ≥ 15 s.

- Hồi phục về STANDING: θ < 35° VÀ tỷ lệ chiều cao ≥ 0,78; từ ALERT có thể bấm “Tôi ổn”.

- NO_PERSON và PARTIAL_POSE phản ánh chất lượng đầu vào; khi dữ liệu thiếu, ứng dụng không đánh giá ngã. Đây không phải mức nguy hiểm.

Ba điểm cần hiểu đúng:

(i) Bộ đếm đếm theo BƯỚC XỬ LÝ, không theo giây; ở STANDING bộ đếm giảm 1 khi điều kiện sai chứ không đặt lại về 0.

(ii) Thời gian bất động là TÍCH LŨY; một cử động nhỏ chỉ trừ 0,2 s, nên không phải "15 giây liên tục".

(iii) Hai mốc 15 s nối tiếp (bất động của FSM rồi đếm ngược của hộp thoại).

CÂU CHUYỂN Ý: Phần kỹ thuật đã đủ. Nhóm em chia sẻ quá trình xây dựng ứng dụng.

NGUỒN: FINAL 4, mục 2.3 (Hình 1) và mục 3.2 (Bảng 1); khái niệm FSM theo Hopcroft, Motwani và Ullman [10].

KẾ HOẠCH HIỆU ỨNG: Chuyển trang Fade 0,30 s. Bấm 1: ô chất lượng đầu vào và STANDING. Bấm 2: đường chính sang PRE_FALL, FALLEN, ALERT (mũi tên Wipe 0,25 s, ô Fade 0,20 s). Bấm 3: các nhánh hồi phục và ghi chú.