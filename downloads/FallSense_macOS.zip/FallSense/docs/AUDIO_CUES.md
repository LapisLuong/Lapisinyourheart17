# Nhạc nền phần mở đầu

Người dùng đã chọn “Làm nhạc nền cho phần mở đầu 43 giây”. Không dùng hình của clip nhạc trong output.

- File nguồn MP4: 65,000s, hình H.264 1024×576; audio AAC stereo 44.100 Hz, 64,993s.
- Audio được tách bằng stream copy vào `public/audio/user-supplied.m4a`.
- FFmpeg đo toàn nguồn: integrated loudness −12,98 LUFS; true peak −0,02 dBTP; LRA 1,60 LU. Kết quả phân tích lưu `out/audio-analysis.log`.
- Chọn đoạn 0–43s, gain tuyến tính 0,4 (khoảng −7,96dB). Không time-stretch và không loop.
- 00:00–00:01,200: fade-in tuyến tính.
- 00:01,200–00:40: phát nền ở gain đã chọn.
- 00:40–00:43: fade-out tuyến tính vào title handoff.
- Sau 00:43: không có nhạc, để thuyết trình trực tiếp.

Đây là cue theo cấu trúc hình ảnh, không phải beat detection. Không chạy ASR, không tạo lời bài hát hoặc transcript giả. Loại sử dụng là nhạc nền do người dùng xác nhận; chưa phân loại nội dung giọng hát/giọng nói bằng nhận dạng âm thanh. Voiceover học thuật vẫn chưa có.

`AudioTimeline` trong Remotion và `scripts/mix-audio.py` dùng cùng cấu hình gain/fade. Bản xuất nhanh giữ nguyên video H.264 bằng stream copy và mã hóa audio AAC 48kHz/192kbps. Các bản `_Silent.mp4` được giữ riêng.
