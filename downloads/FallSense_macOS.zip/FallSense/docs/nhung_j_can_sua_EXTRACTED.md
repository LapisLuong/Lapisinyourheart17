# nhung_j_can_sua.pptx

## ppt/slides/slide1.xml

Hướng dẫn sửa bài trình bày FallSense

Bản góp ý trực quan theo cách trình bày của “sua bai.pptx”

HƯỚNG DẪN SỬA • FALLSENSE

01

Bản gốc hiện có 10 slide

Tên tệp ghi “13slide”. Bản hướng dẫn này đánh số theo 10 slide thực tế và đề xuất cách bổ sung thành 13 slide.

Các điểm cần sửa trước

1. Đồng bộ tên FallSense và nội dung cảnh báo email.

2. Giải thích khung bao, Fall Score và điều kiện chuyển trạng thái.

3. Cập nhật luồng đếm ngược theo mã nguồn hiện tại.

Mỗi trang chỉ rõ slide cần sửa, lý do và câu chữ có thể thay vào bài.

## ppt/slides/slide2.xml

Slide 1 • Tên ứng dụng cần xuất hiện rõ

Đối chiếu slide 1 trong bản gốc • ảnh bên trái giữ nguyên để xác định vị trí sửa

HƯỚNG DẪN SỬA • FALLSENSE

02

Sửa tiêu đề chính

Đưa “FallSense” thành tên sản phẩm. Giữ tên môn, nhóm, lớp và giảng viên.

Giữ đúng phạm vi

Dùng “giám sát và cảnh báo té ngã”. Thống nhất tên trên ảnh giao diện và phần demo.

NỘI DUNG ĐỀ XUẤT

FallSense

Hệ thống hỗ trợ giám sát và cảnh báo té ngã bằng camera

## ppt/slides/slide3.xml

Slide 2 • Giữ số liệu, ghi rõ đối tượng nghiên cứu

Đối chiếu slide 2 trong bản gốc • ảnh bên trái giữ nguyên để xác định vị trí sửa

HƯỚNG DẪN SỬA • FALLSENSE

03

Giữ mẫu số 66

80% và 30% thuộc nhóm người trên 90 tuổi đã ngã trong một nghiên cứu. Không suy rộng cho mọi người cao tuổi.

Bổ sung cách đọc nguồn

Ghi “ước tính” cho 684.000 ca. Giữ năm 2021 nếu trích tài liệu WHO năm 2021.

NỘI DUNG ĐỀ XUẤT

Trong 66 người trên 90 tuổi đã ngã: 53 người không tự đứng dậy ít nhất một lần, 20 người nằm trên sàn ≥ 1 giờ.

## ppt/slides/slide4.xml

Slide 3 • Phạm vi cần khớp phiên bản FallSense

Đối chiếu slide 3 trong bản gốc • ảnh bên trái giữ nguyên để xác định vị trí sửa

HƯỚNG DẪN SỬA • FALLSENSE

04

Bổ sung phản hồi qua email

Bản hiện tại có cảnh báo tại chỗ, nút “Tôi ổn” và gửi email cho người nhận đã cấu hình.

Tách xử lý và gửi tin

Ước lượng tư thế chạy trên thiết bị. Gửi email cần kết nối mạng và dịch vụ gửi thư hoạt động.

NỘI DUNG ĐỀ XUẤT

Nguyên mẫu học tập: hỗ trợ phát hiện dấu hiệu té ngã và thông báo cho người chăm sóc.

## ppt/slides/slide5.xml

Slide 4 • Luồng tổng quan còn thiếu bước tính điểm

Đối chiếu slide 4 trong bản gốc • ảnh bên trái giữ nguyên để xác định vị trí sửa

HƯỚNG DẪN SỬA • FALLSENSE

05

Sửa bước “Phân tích diễn biến”

Mô tả rõ: trích đặc trưng chuyển động, tính Fall Score rồi xét điều kiện theo thời gian.

Sửa bước phản hồi

Khi xác nhận ngã: phát âm báo, mở đếm ngược. Hết thời gian không hủy thì thực hiện gửi cảnh báo.

NỘI DUNG ĐỀ XUẤT

Camera → Điểm mốc tư thế → Fall Score và chuyển trạng thái → Cảnh báo, phản hồi

## ppt/slides/slide6.xml

Slide 5 • Giao diện cần có ảnh từ bản đang demo

Đối chiếu slide 5 trong bản gốc • ảnh bên trái giữ nguyên để xác định vị trí sửa

HƯỚNG DẪN SỬA • FALLSENSE

06

Thay hình minh họa khi có ảnh thật

Chụp màn Giám sát của FallSense. Giữ chú thích rõ “minh họa” nếu tiếp tục dùng hình vẽ hiện tại.

Sửa các nhãn giải thích

ID là mã theo dõi tạm thời. Fall Score là điểm tổng hợp 0–1. Phân biệt điểm này với chất lượng điểm mốc.

NỘI DUNG ĐỀ XUẤT

ID: mã theo dõi tạm thời. Fall Score: điểm tổng hợp hỗ trợ đánh giá dấu hiệu ngã.

## ppt/slides/slide7.xml

Slide 6 • Hai mốc 15 giây không còn nối tiếp

Đối chiếu slide 6 trong bản gốc • ảnh bên trái giữ nguyên để xác định vị trí sửa

HƯỚNG DẪN SỬA • FALLSENSE

07

Luồng trong mã nguồn hiện tại

Khi vào FALLEN, ứng dụng mở hộp thoại đếm ngược 15 giây ngay. Không chờ đủ 15 giây bất động để mở.

Thay phần trình quay số

Bỏ nội dung mở trình quay số. Thay bằng gửi email khi hết đếm ngược hoặc bấm “Gửi cảnh báo ngay”.

NỘI DUNG ĐỀ XUẤT

Xác nhận ngã → mở đếm ngược 15 giây → gửi email nếu chưa hủy. “Tôi ổn” hủy phản hồi.

## ppt/slides/slide8.xml

Slide 7 • 33 điểm mốc là dữ liệu đầu vào

Đối chiếu slide 7 trong bản gốc • ảnh bên trái giữ nguyên để xác định vị trí sửa

HƯỚNG DẪN SỬA • FALLSENSE

08

Giữ ý chính của slide

MediaPipe ước lượng 33 điểm mốc cho mỗi tư thế phát hiện được. Các điểm có thể bị che hoặc có chất lượng thấp.

Sửa câu giải thích

FallSense dùng các điểm mốc để tính đặc trưng. Bộ quy tắc, mô hình hỗ trợ nếu bật và điều kiện thời gian quyết định trạng thái.

NỘI DUNG ĐỀ XUẤT

33 điểm mốc mô tả tư thế cơ thể. Chúng là đầu vào cho bước phân tích té ngã.

## ppt/slides/slide9.xml

Slide 8 • Chất lượng tư thế khác với hướng khung bao

Đối chiếu slide 8 trong bản gốc • ảnh bên trái giữ nguyên để xác định vị trí sửa

HƯỚNG DẪN SỬA • FALLSENSE

09

Sửa nhãn “Đủ điều kiện”

Đổi thành “Đủ dữ liệu để đánh giá ngã”. Tránh làm người nghe hiểu có đủ dữ liệu là đã phát hiện ngã.

Bổ sung một slide riêng

Sau slide này, giải thích khung bao đứng/ngang. Không thay kiểm tra chất lượng bằng quy tắc hình chữ nhật.

NỘI DUNG ĐỀ XUẤT

Thiếu dữ liệu tư thế không đồng nghĩa an toàn. Hệ thống cần đủ điểm mốc tin cậy để tiếp tục đánh giá.

## ppt/slides/slide10.xml

Slide mới • Khung bao đứng/ngang được dùng thế nào?

Chèn sau slide 8 gốc • đáp ứng góp ý trong “sua bai.pptx”

HƯỚNG DẪN SỬA • FALLSENSE

10

Công thức từ các điểm mốc hợp lệ

W = xmax − xmin

H = ymax − ymin

r = W / H

Trong hệ tọa độ chuẩn hóa đang dùng:

r < 0,75: khung dọc

r > 1,30: khung ngang

Còn lại: gần vuông

Câu cần thay cho nhận xét trong mẫu

Khung ngang là một dấu hiệu hỗ trợ. Hệ thống còn xét góc thân, tốc độ hạ người, giảm chiều cao và diễn biến theo thời gian.

## ppt/slides/slide11.xml

Slide 9 • Giữ trọng số, làm rõ ý nghĩa Fall Score

Đối chiếu slide 9 trong bản gốc • ảnh bên trái giữ nguyên để xác định vị trí sửa

HƯỚNG DẪN SỬA • FALLSENSE

11

Bảy trọng số đang khớp mã

Tổng bằng 1,00. Đổi “Hạ thấp kéo dài” thành “Vận tốc dọc duy trì” để sát đặc trưng đang tính.

Đổi “Điểm gần đáy khung”

Dùng “Số điểm mốc gần đáy ảnh”. Đây là dấu hiệu hình học, chưa xác nhận tiếp xúc với sàn thật.

NỘI DUNG ĐỀ XUẤT

Fall Score là điểm tổng hợp 0–1. Giá trị 0,68 là ngưỡng cấu hình, không biểu thị xác suất ngã 68%.

## ppt/slides/slide12.xml

Slide mới • Ví dụ tính Fall Score

Chèn sau slide 9 gốc • ví dụ số giả định, chỉ minh họa phép tính

HƯỚNG DẪN SỬA • FALLSENSE

12

Thành phần

Điểm đã chuẩn hóa

Trọng số

Đóng góp

Vận tốc dọc

0,75

0,22

0,165

Góc thân

0,50

0,20

0,100

Giảm chiều cao

0,60

0,18

0,108

Đầu thấp hơn hông

0,00

0,12

0,000

Tư thế ngang

0,50

0,12

0,060

Vận tốc dọc duy trì

0,60

0,08

0,048

Điểm mốc gần đáy ảnh

0,50

0,08

0,040

Tổng đóng góp = 0,521

Giả sử hệ số vùng = 1 và chưa dùng model hỗ trợ. Điểm vượt 0,45 chưa tự xác nhận ngã. Hệ thống còn xét dữ liệu hợp lệ và điều kiện thời gian.

## ppt/slides/slide13.xml

Slide 10 • Tiêu đề và các nhãn chuyển trạng thái

Đối chiếu slide 10 trong bản gốc • ảnh bên trái giữ nguyên để xác định vị trí sửa

HƯỚNG DẪN SỬA • FALLSENSE

13

Đổi tiêu đề cho dễ hiểu

Dùng “Sơ đồ chuyển trạng thái”. “Máy trạng thái” là thuật ngữ hợp lệ, không phải lỗi chính tả.

Các điều kiện đang rút gọn quá mức

0,45 cần tích lũy đủ bước xử lý. 0,68 còn đi kèm góc thân > 60°. Có thêm nhánh giảm chiều cao nhanh.

NỘI DUNG ĐỀ XUẤT

Bình thường → Nghi ngờ ngã → Xác nhận ngã → Cảnh báo. Mỗi chuyển trạng thái có điều kiện riêng.

## ppt/slides/slide14.xml

Nhãn đề xuất cho sơ đồ trạng thái

Dùng nội dung này để viết lại slide 10 gốc, giữ sơ đồ gọn

HƯỚNG DẪN SỬA • FALLSENSE

14

Chuyển trạng thái

Nhãn đặt trên mũi tên

STANDING sang PRE_FALL

Hạ nhanh và nghiêng thân, hoặc điểm ≥ 0,45 tích lũy đủ 3 bước

PRE_FALL sang FALLEN

Dấu hiệu ngang đủ 4 bước, hoặc điểm ≥ 0,68 kèm góc > 60°, hoặc giảm chiều cao nhanh kèm điểm gần đáy ảnh

FALLEN sang ALERT

Bất động tích lũy đạt ngưỡng cấu hình, mặc định 15 giây

Phục hồi / Tôi ổn

Xét phục hồi tư thế hoặc tiếp nhận thao tác hủy cảnh báo

Điều kiện chung: người được xác nhận và dữ liệu thân đủ tin cậy.

Ghi chú dưới sơ đồ: “Hộp thoại đếm ngược mở ngay khi xác nhận FALLEN. Bộ đếm bước xử lý khác với thời gian tính bằng giây.”

## ppt/slides/slide15.xml

Thứ tự đề xuất để hoàn thiện 13 slide

Giữ 10 slide gốc, bổ sung đúng 3 slide giải thích và đánh giá

HƯỚNG DẪN SỬA • FALLSENSE

15

Số mới

Nội dung

Thao tác

01–04

Tên đề tài, bối cảnh, phạm vi, luồng xử lý

Sửa slide gốc 1–4

05–08

Giao diện, cảnh báo, điểm mốc, chất lượng tư thế

Sửa slide gốc 5–8

09

Khung bao và tỉ lệ rộng/cao

Bổ sung sau slide gốc 8

10

Công thức và trọng số Fall Score

Dùng slide gốc 9 đã sửa

11

Ví dụ tính điểm tổng hợp

Bổ sung sau phần trọng số

12

Sơ đồ chuyển trạng thái

Dùng slide gốc 10 đã sửa

13

Minh họa kiểm thử, giới hạn và kết luận

Bổ sung cuối bài

Nguồn tham khảo đặt trong ghi chú của từng slide và tài liệu kèm bài. Nếu cần trình chiếu danh mục riêng, thêm phụ lục ngoài 13 slide chính.

## ppt/slides/slide16.xml

Slide mới cuối bài • Demo và giới hạn

Nội dung có thể đưa vào slide 13 đề xuất

HƯỚNG DẪN SỬA • FALLSENSE

16

Kịch bản minh họa

Đứng hoặc ngồi bình thường.

Cúi người và ngồi xuống nhanh.

Tư thế thiếu điểm mốc.

Chuỗi ngã mô phỏng có kiểm soát.

Hủy cảnh báo hoặc kiểm tra gửi email.

Điều cần ghi nhận

Số lần phát hiện đúng và bỏ sót.

Số cảnh báo sai.

Thời gian đến khi mở hộp thoại.

Trạng thái gửi email.

Thiết bị, ánh sáng và góc camera.

Giới hạn

Chưa có kết quả đo hiệu quả phát hiện trên dữ liệu thực trong bộ tài liệu hiện tại. Test phần mềm đạt không đồng nghĩa ứng dụng đạt độ chính xác lâm sàng.

## ppt/slides/slide17.xml

Ba PDF tham khảo hỗ trợ phần nào?

Dùng khi bổ sung nguồn và chuẩn bị trả lời câu hỏi

HƯỚNG DẪN SỬA • FALLSENSE

17

Tài liệu

Có thể tham khảo

Không suy diễn

Trần Thị Hồng Ân và cs. (2017)

Theo dõi khách hàng trong siêu thị

Theo dõi đối tượng, quỹ đạo và phân tích hành vi

Đây không phải nghiên cứu phát hiện té ngã

Nguyễn Phước Đại Toàn và cs.

NCKH 2022–2023, ĐH Bách khoa Đà Nẵng

Hai hướng top-down/bottom-up kết hợp LSTM

99,82% và 99,63% là kết quả của bài báo, không phải FallSense

Đỗ Trí Nhựt, Lê Thị Thủy (2025)

Học sâu trên dữ liệu khung xương

33 điểm mốc, chuỗi thời gian và đánh giá mô hình

BiLSTM 97,32% thuộc tập thử nghiệm của bài báo

Chỉ so sánh số đo khi cùng bộ dữ liệu, cách chia tập, nhãn sự kiện và điều kiện thử nghiệm.

## ppt/slides/slide18.xml

Danh sách kiểm tra sau khi sửa

Dùng để rà lại bài trước khi trình bày

HƯỚNG DẪN SỬA • FALLSENSE

18

Nội dung

Tên FallSense nhất quán.

Luồng email và đếm ngược đúng phiên demo.

Phân biệt chất lượng tư thế với dấu hiệu ngã.

Không gọi Fall Score là xác suất.

Ngưỡng điểm có điều kiện đi kèm.

Trình bày và nguồn

Ảnh giao diện có nhãn thật/minh họa.

Xóa dấu chấm rời ở slide 5 và 6.

Tiêu đề “Sơ đồ chuyển trạng thái”.

Ghi nguồn ngay cạnh số liệu.

Đánh lại số trang sau khi chèn slide.

Câu trả lời ngắn khi được hỏi

“Hệ thống kết hợp hình học tư thế, chuyển động và điều kiện theo thời gian. Điểm số hỗ trợ quyết định. Nhóm cần đánh giá trên dữ liệu thực để kết luận hiệu quả.”

## ppt/notesSlides/notesSlide1.xml

Phạm vi: tạo file hướng dẫn sửa riêng, không ghi đè bài trình bày gốc. Đã đọc 3 PDF và 2 PPTX đính kèm. Chưa nhận được bộ Markdown mang số 01–05. Đối chiếu bổ sung nhom.zip, tệp đã có trong cuộc hội thoại ngày 26/10/2026, bằng cách đọc mã nguồn và báo cáo liên quan. Không chạy ứng dụng, không chứng nhận hành vi trên thiết bị thực.

## ppt/notesSlides/notesSlide2.xml

Nguồn: bài trình bày gốc slide 1; sua bai.pptx slide 2. Đối chiếu nhom.zip: FALLSENSE_REBRAND_CLEANUP_REPORT.md và src/components/common/Header.tsx. Bản rebrand tập trung vào té ngã. Chỉ sửa tên và dòng mô tả, giữ thông tin học phần, lớp, giảng viên và nhà trường.

## ppt/notesSlides/notesSlide3.xml

Nguồn kiểm tra: WHO, Step Safely (27/4/2021), https://www.who.int/teams/social-determinants-of-health/safety-and-mobility/step-safely : 684.000 ca tử vong mỗi năm. Fleming J, Brayne C. Inability to get up after falling, subsequent time on floor, and summoning help. BMJ 2008;337:a2227. https://www.bmj.com/content/337/bmj.a2227 và https://pubmed.ncbi.nlm.nih.gov/19015185/ . Tỉ lệ 53/66 và 20/66 làm tròn lần lượt thành 80% và 30%. Không dùng các tỉ lệ này như số liệu đánh giá ứng dụng.

## ppt/notesSlides/notesSlide4.xml

Nguồn: slide 3 gốc. nhom.zip: src/components/monitor/CameraMonitor.tsx, src/components/emergency/EmergencyModal.tsx, src/services/emergency/emergencyOrchestrator.ts, FALLSENSE_REBRAND_CLEANUP_REPORT.md. Không tuyên bố toàn bộ hệ thống luôn hoạt động ngoại tuyến: mô hình/tài nguyên cần được tải và kênh email cần backend/SMTP cùng kết nối mạng. Không đưa tính năng đột quỵ, gọi 115 hay gọi điện tự động vào bài FallSense hiện tại.

## ppt/notesSlides/notesSlide5.xml

Nguồn: slide 4 gốc. nhom.zip: src/cv/features/featureExtractor.ts; src/cv/fall-engine/fallDetectionEngine.ts; src/components/monitor/CameraMonitor.tsx. Các mũi tên trong dòng đề xuất mô tả thứ tự xử lý. Bỏ hoặc thay dòng “theo báo cáo FINAL 4” vì tài liệu này không nằm trong bộ đính kèm đã đọc. Dùng chú thích “Sơ đồ luồng xử lý FallSense, đối chiếu mã nguồn phiên bản trình bày”.

## ppt/notesSlides/notesSlide6.xml

Nguồn: slide 5 gốc; nhom.zip src/components/monitor/TelemetryPanel.tsx, src/cv/tracking/personTracker.ts và src/cv/pose/overlayRenderer.ts. Hình bên trái là minh họa từ bài gốc, không phải ảnh ứng dụng mới. Chưa có ảnh chụp phiên chạy hiện tại để thay thế. Khi chụp, dùng cùng ngôn ngữ và cùng chế độ AI như phiên demo. Không giải thích 68% trên giao diện như xác suất ngã hoặc độ chính xác của toàn hệ thống. Xóa dấu chấm rời ở góc dưới slide.

## ppt/notesSlides/notesSlide7.xml

Đối chiếu trực tiếp nhom.zip: src/components/monitor/CameraMonitor.tsx, onTransition: event.newState === FALLEN gọi setAlertingPerson ngay. EmergencyModal được mount khi alertingPerson có giá trị. src/components/emergency/EmergencyModal.tsx đặt deadline Date.now()+15000 và gọi triggerEmergencyDispatch khi hết hạn. Trong engine, FALLEN vẫn tích lũy bất động và chuyển ALERT tại inactivityThresholdSeconds, mặc định 15 giây. Hai cơ chế cùng tồn tại, không phải chờ 15 giây rồi mới bắt đầu thêm 15 giây. Báo cáo rebrand loại bỏ tel:115/tel:112. Đây là kết luận từ đọc mã, cần demo xác nhận hành vi trên bản dùng trình bày. Xóa dấu chấm rời phía dưới.

## ppt/notesSlides/notesSlide8.xml

Nguồn: slide 7 gốc; PDF 03: Đỗ Trí Nhựt và Lê Thị Thủy (2025), trang in 34–36, dùng MediaPipe Pose 33 điểm mốc. Đối chiếu nhom.zip: src/cv/features/featureExtractor.ts, src/cv/fall-engine/fallDetectionEngine.ts. Không nói MediaPipe tự trả kết luận ngã. Không bắt buộc cả 33 điểm đều nhìn rõ mới có thể đánh giá, vì cổng chất lượng sử dụng các nhóm điểm và độ hiển thị.

## ppt/notesSlides/notesSlide9.xml

Nguồn: slide 8 gốc; sua bai.pptx slide 1. nhom.zip src/cv/validation/humanValidationGate.ts: canEvaluateFall = reliableTorso && (hasLowerJoint || (torsoCount === 4 && completeness >= 0.40)). Vì vậy câu “phải thấy chân” trong slide gốc quá tuyệt đối: trường hợp đủ 4 điểm thân và completeness đạt ngưỡng vẫn có thể đánh giá. ID không phải nhận diện danh tính và có thể đổi khi che khuất/giao cắt. Khung bao và chất lượng tư thế là hai nhóm thông tin khác nhau.

## ppt/notesSlides/notesSlide10.xml

Nguồn hình: sua bai.pptx slide 1. Hình được dùng để chỉ vị trí góp ý, không dùng làm chứng cứ vận hành. nhom.zip src/cv/features/featureExtractor.ts calculateBodyDimensions tính bao từ điểm có visibility >0.3; aspectRatio = currentWidth/currentHeight nếu height >0.01; boxOrientation: >1.3 horizontal, <0.75 vertical, còn lại square. Đây là tỉ lệ trong hệ tọa độ x/y chuẩn hóa hiện có trong mã, không tự đổi sang tỉ lệ pixel. HorizontalScore thực tế là clamp((r−0.9)/0.8,0,1), nên nhãn khung ngang và mức điểm không phải cùng một ngưỡng. Không có quy tắc tổng quát “khung đứng thì không nhận tín hiệu ngã”. Người nằm chủ động có thể tạo khung ngang, camera chéo/che khuất có thể làm sai hình dạng.

## ppt/notesSlides/notesSlide11.xml

Nguồn: slide 9 gốc; nhom.zip src/config/fallDetectionConfig.ts và src/cv/features/featureExtractor.ts. Trọng số: velocity .22, torsoAngle .20, heightDrop .18, headBelowHip .12, horizontalPose .12, sustainedVerticalSpeed .08, groundContact .08, tổng 1.00. Góc được chuẩn hóa bằng clamp((góc−25)/45), đạt 1 ở 70°, dù comment trong mã còn ghi 65°. Ground contact đếm điểm visibility>0.3 và y>0.78, không sử dụng cảm biến sàn hay tái dựng sàn. Nếu classifier đang triển khai và hợp lệ, điểm cuối = max(ruleScore, 0.68×classifierScore), vẫn phải qua điều kiện hình học và thời gian. Nêu rõ chế độ đang dùng trong demo.

## ppt/notesSlides/notesSlide12.xml

Nguồn phương pháp: nhom.zip src/cv/features/featureExtractor.ts, computeMultiSignalScore. Các điểm thành phần là ví dụ giả định của người biên soạn, không phải mẫu đo từ ứng dụng hoặc dữ liệu thực. Phép tính: .75*.22 + .5*.20 + .6*.18 + 0*.12 + .5*.12 + .6*.08 + .5*.08 = .521. Score = min(1,max(0,hệ số vùng×tổng đóng góp)). Ví dụ riêng cho góc thân: 47.5° cho angleScore=(47.5−25)/45=.5 và đóng góp .1. Không quy đổi thành độ chính xác 52.1%. Trọng số không phải kết quả học được từ ba bài báo.

## ppt/notesSlides/notesSlide13.xml

Nguồn: sua bai.pptx slide 3, slide 10 gốc. nhom.zip src/cv/fall-engine/fallDetectionEngine.ts và src/config/fallDetectionConfig.ts. STANDING vào PRE_FALL khi suddenDrop (v>0.9 và góc>35) hoặc consecutiveTriggerCount≥3, đồng thời người đã xác nhận và tư thế/thân hợp lệ. PRE_FALL vào FALLEN khi bộ đếm ngang≥4 hoặc (score≥.68 và góc>60) hoặc (rapidHeightReduction và groundContactCount≥2), kèm cổng người/thân hợp lệ. Bộ đếm có tăng/giảm theo logic, không nên nói mọi trường hợp là “4 khung liên tiếp”. FALLEN vào ALERT sau bất động tích lũy đạt ngưỡng, mặc định 15 giây. Hộp thoại UI đã mở từ FALLEN, không phải đợi ALERT.

## ppt/notesSlides/notesSlide14.xml

Nguồn: nhom.zip src/cv/fall-engine/fallDetectionEngine.ts, src/config/fallDetectionConfig.ts và src/components/monitor/CameraMonitor.tsx. Đây là nhãn tóm tắt để trình bày, không phải đặc tả toàn bộ nhánh và điều kiện phục hồi. 3 bước và 4 bước là ngưỡng mặc định. Bộ đếm trigger giảm decayFactor khi điểm thấp, bộ đếm ngang có hành vi tích lũy khác nhau giữa trạng thái STANDING/PRE_FALL. Dùng từ “tích lũy đủ” thay cho khẳng định tất cả phải liên tiếp.

## ppt/notesSlides/notesSlide15.xml

Đề xuất bố cục của người biên soạn. Tệp mang tên GIOI_THIEU_NGANH_Nhom06_13slide.pptx có 10 slide thực tế. Người dùng yêu cầu file hướng dẫn sửa riêng, không yêu cầu ghi đè nguồn. 13 slide là phương án hoàn thiện tương ứng tên tệp, không phải khẳng định nguồn ban đầu có đủ 13 trang.

## ppt/notesSlides/notesSlide16.xml

Nguồn: nhom.zip AI_LAB_TRAINING_VALIDATION_REPORT.md, cập nhật 25/10/2026: hiệu quả phát hiện té ngã trên dữ liệu thực chưa được đo, không có chứng nhận model mới tốt hơn baseline. Danh sách kịch bản trên là đề xuất kiểm thử, không phải kết quả đã thực hiện. Chỉ điền số đo khi có log/video và điều kiện kiểm thử. Không yêu cầu người cao tuổi thực hiện ngã thật để demo. Ghi rõ mô phỏng và dùng điều kiện kiểm soát. Các giới hạn về ánh sáng/vật cản/góc quay cũng được PDF 03 trình bày ở phần kết luận trang in 43.

## ppt/notesSlides/notesSlide17.xml

Nguồn PDF 01: Trần Thị Hồng Ân, Phạm Nguyên Khang, Trần Minh Tân. Ứng dụng kỹ thuật theo dõi đối tượng cho bài toán nhận dạng hành vi của khách hàng trong siêu thị. Tạp chí Khoa học Trường Đại học Cần Thơ, Số chuyên đề CNTT (2017):1–9. DOI 10.22144/ctu.jsi.2017.001. Trang 1 tóm tắt, trang 2–4 hệ thống theo dõi. PDF 02: Hệ thống cảnh báo phát hiện té ngã trong phòng bằng camera. Hội nghị SV NCKH ĐH Bách khoa Đà Nẵng năm học 2022–2023. Trang in 5, Bảng 1: top-down/LSTM đạt 99.82% ở chuỗi 40 frame; Bảng 2: bottom-up/LSTM đạt 99.63% ở 35 frame. Bảng 3 so sánh cùng 30 frame cho 99.58% và 99.26%, vì thế không trộn điểm tối đa với cấu hình so sánh đồng nhất. PDF 03: Đỗ Trí Nhựt, Lê Thị Thủy. Ứng dụng học sâu trong phát hiện té ngã dựa trên dữ liệu khung xương. Tạp chí Khoa học Đại học Thủ Dầu Một 4(77),2025, trang 34–43. Trang 40 Bảng 2: BiLSTM accuracy97.32%,F1 97.20%. Các tài liệu được đọc từ PDF đính kèm.

## ppt/notesSlides/notesSlide18.xml

Các góp ý được tổng hợp từ 10 slide gốc, 3 slide có nội dung trong sua bai.pptx (slide thứ 4 trống), ba PDF đính kèm và mã nguồn/báo cáo trong nhom.zip ngày 26/10/2026. Không có bộ 01–05.md được cung cấp trong lần đính kèm này hoặc tìm thấy dưới tên đó. Bản hướng dẫn này không thay thế việc đọc bộ Markdown nếu người dùng cung cấp bổ sung. Không chạy thử gửi email và không chỉnh mã nguồn ứng dụng trong tác vụ này.