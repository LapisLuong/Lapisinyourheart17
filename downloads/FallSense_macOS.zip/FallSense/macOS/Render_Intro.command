#!/bin/bash
set -euo pipefail
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
cd "$(dirname "$0")/.."
trap 'status=$?; if [ "$status" -ne 0 ]; then echo "Da dung vi loi. Xem thong bao phia tren."; read -r -p "Nhan Enter de dong..." _; fi' EXIT
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Can cai Node.js 22 hoac 24 LTS tu https://nodejs.org/ roi mo lai file nay."
  exit 1
fi
node -e 'if(Number(process.versions.node.split(".")[0])<22){console.error("Can Node.js >=22");process.exit(1)}'
npm ci --cache "$PWD/.cache/npm" --no-audit --no-fund
npm run render:intro
