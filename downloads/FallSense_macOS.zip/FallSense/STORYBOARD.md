# Storyboard và shot list

| Timecode | Hình ảnh và chuyển động | Asset / kiểm soát nội dung |
|---|---|---|
| 00:00–00:06 | Nền cyclorama pastel; shield chibi thả xuống bằng spring, nhún, vẫy tay, chớp mắt | Vector nguyên bản; lời “Một người bạn nhỏ.” |
| 00:06–00:12 | Wordmark FallSense và mô tả fade/slide lên; mascot cùng sân khấu | Chữ Việt local font; slogan không phải cam kết y khoa |
| 00:12–00:21 | Overview từ perspective 15° về chính diện; callout Camera/Giám sát/Trạng thái | overview.jpg; ghi chưa khởi động |
| 00:21–00:25 | Live Monitor tiến vào | live-monitor.jpg; DEMO SIM |
| 00:25–00:29 | AI Training Lab | training.jpg; phân tích, gắn nhãn |
| 00:29–00:33 | Incidents | incidents.jpg; lịch sử sự cố |
| 00:33–00:37 | Settings | settings.jpg; che toàn vùng thông tin người nhận |
| 00:37–00:40 | Bốn panel thu nhỏ, mascot hướng sang slide, nền pastel trắng mở ra | Không cắt đen; shield-fold morph phức tạp chưa thực hiện |
| 00:40–00:43 | Title học thuật cùng nền và mascot; giữ 3s | Bắt đầu title duy nhất của FullShow |
| 00:43–kết | 12 slide tiếp theo, spring 0.3–0.8s và nội dung rõ | Timing trong config; notes chi tiết riêng |

Chuyển carousel hiện là vào theo chiều sâu rồi đổi scene; chưa có rack-focus liên tục hoặc camera 3D thực. Mascot chọn fallback 2.5D từ đầu vì không có GLB và ưu tiên render Chromium ổn định; không tuyên bố đã thử thất bại React Three Fiber.
