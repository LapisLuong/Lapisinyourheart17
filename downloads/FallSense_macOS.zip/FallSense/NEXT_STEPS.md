# Trạng thái hoàn thiện và hướng phát triển

## Đã triển khai

- Dự án Remotion/React/TypeScript chạy được, ba composition 1080p60, thời lượng suy ra từ config.
- Intro 43s: mascot shield 2.5D nguyên bản, wordmark, Overview, bốn giao diện và title handoff.
- 13 slide tiếng Việt, ảnh UI thật, pose schematic, trọng số, ví dụ giả định, trạng thái và giới hạn.
- Font tiếng Việt local, animation deterministic, mask vùng Settings, phân biệt DEMO SIM và kết quả kiểm thử.
- Audit trích text/notes, mapping 10→13, storyboard, lời dẫn, phụ đề cue, nguồn và quyền sử dụng.
- Đã ghép nhạc người dùng cung cấp vào 43 giây mở đầu, có fade-in/out; phần slide sau đó không nhạc.

## Chưa đạt đầy đủ ý đồ cinematic

- Mascot là 2.5D, chưa có mesh 3D/R3F, camera vật lý, phản xạ và ánh sáng 3D.
- Carousel hiện chuyển panel theo chiều sâu từng cảnh; chưa có chuyển động slider liên tục, DOF hoặc morph panel thành shield.
- Slide phần lớn dùng thẻ, sơ đồ và bar reveal; chưa morph icon/đường nối liên tục giữa mọi slide.
- Đã có nhạc nền intro; chưa có SFX, voiceover hoặc đồng bộ theo giọng đọc. Quyền tái sử dụng công khai của nhạc nguồn chưa xác minh.
- Chưa có PPTX chỉnh sửa được; Remotion source/config là bản chỉnh sửa chính.

## Thứ tự phát triển tiếp

1. **Xác minh ứng dụng:** nhận source app đúng commit, đọc READ-ONLY; đối chiếu ngưỡng .60/.68, bảy đặc trưng, gating, classifier và countdown. Chạy demo kiểm soát, quay UI mới, thử email qua tài khoản/dịch vụ được phép. Không gửi cho người khác khi chưa được cho phép.
2. **Hoàn thiện chuyển động:** mascot mesh 3D nguyên bản hoặc GLB có quyền dùng; thử headless với 5 khung, sau đó camera spline, carousel liên tục, shield-fold transition. Giữ 2.5D fallback.
3. **Âm thanh:** nhạc intro đã ghép; tiếp theo thu lời dẫn theo script, kiểm tra transcript/timecode thực; điều chỉnh timing, duck nền theo cue và xuất bản mix. Không suy diễn lời nói từ video không tiếng.
4. **Kiểm thử nội dung cuối:** xác minh trực tiếp WHO/BMJ, chốt mốc dữ liệu với nhóm; kiểm tra trên màn chiếu và điều chỉnh phần chữ nhỏ trong screenshot. Bổ sung PPTX nếu cần điều khiển bằng click.
5. **Đo sản phẩm riêng:** quy trình dữ liệu có nhãn, baseline và thống kê false positive/negative, latency; không trộn kết quả phần mềm với hiệu quả lâm sàng.

Các mục cần source app hoặc audio không thể được chứng nhận từ ảnh chụp. Bản dựng hiện tại dùng nhãn thận trọng để tiếp tục công việc mà không bịa kết quả.
