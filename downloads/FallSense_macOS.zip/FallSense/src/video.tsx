import React from "react";
import {
  AbsoluteFill,
  Audio,
  Composition,
  Img,
  Sequence,
  continueRender,
  delayRender,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import {
  config,
  slides,
  slideFrames,
  introFrames,
  presentationFrames,
  weights,
  featureNames,
  example,
  Slide,
} from "./config";
const C = config.colors;
const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
const enter = (f: number, d = 0) =>
  spring({ frame: f - d, fps: 60, config: { damping: 22, stiffness: 90 } });
const fontGate = delayRender("Load local Vietnamese fonts");
Promise.all([
  new FontFace(
    "Noto",
    `url(${staticFile("fonts/NotoSans-Regular.ttf")})`,
  ).load(),
  new FontFace("Noto", `url(${staticFile("fonts/NotoSans-Bold.ttf")})`, {
    weight: "700",
  }).load(),
]).then((fs) => {
  fs.forEach((f) =>
    (document.fonts as FontFaceSet & { add: (font: FontFace) => void }).add(f),
  );
  continueRender(fontGate);
});
export const SoftLight: React.FC = () => (
  <AbsoluteFill
    style={{
      background:
        "radial-gradient(ellipse at 80% 15%,#E9DDF888,transparent 55%),radial-gradient(ellipse at 15% 90%,#F2D8E8aa,transparent 50%)",
    }}
  />
);
export const StudioStage: React.FC<React.PropsWithChildren> = ({
  children,
}) => (
  <AbsoluteFill
    style={{
      background: C.ice,
      color: C.ink,
      fontFamily: "Noto",
      overflow: "hidden",
    }}
  >
    <SoftLight />
    {children}
  </AbsoluteFill>
);
// Original procedural 2.5D fallback: layered vector shield with volumetric shading.
export const Mascot3D: React.FC<{
  size?: number;
  gesture?: "wave" | "point";
  frame?: number;
}> = ({ size = 440, gesture = "wave", frame }) => {
  const current = useCurrentFrame();
  const f = frame ?? current;
  const blink = f % 240 > 226 && f % 240 < 236;
  const y = Math.sin(f / 30) * 7;
  return (
    <div style={{ width: size, height: size, transform: `translateY(${y}px)` }}>
      <svg viewBox="0 0 440 440" width="100%" height="100%">
        <defs>
          <radialGradient id="body" cx="30%" cy="20%" r="85%">
            <stop stopColor="#fff3fc" />
            <stop offset=".45" stopColor="#f0b5d6" />
            <stop offset="1" stopColor="#ca75ac" />
          </radialGradient>
          <linearGradient id="edge">
            <stop stopColor="#f7d7ee" />
            <stop offset="1" stopColor="#b66c9a" />
          </linearGradient>
        </defs>
        <ellipse cx="220" cy="404" rx="120" ry="15" fill="#8e6a931a" />
        <ellipse cx="174" cy="365" rx="25" ry="31" fill="url(#body)" />
        <ellipse cx="268" cy="365" rx="25" ry="31" fill="url(#body)" />
        <g
          transform={`rotate(${gesture === "wave" ? Math.sin(f / 8) * 19 : -35} 340 235)`}
        >
          <ellipse
            cx="354"
            cy="220"
            rx="24"
            ry="58"
            fill="url(#body)"
            transform="rotate(25 354 220)"
          />
        </g>
        <ellipse
          cx="86"
          cy="255"
          rx="25"
          ry="53"
          fill="url(#body)"
          transform="rotate(20 86 255)"
        />
        <path
          d="M220 54 Q280 91 337 94 Q355 209 311 291 Q280 350 220 375 Q159 350 126 291 Q83 209 103 94 Q165 90 220 54"
          fill="url(#edge)"
          transform="translate(5 8)"
        />
        <path
          d="M220 48 Q280 85 337 88 Q355 203 311 285 Q280 344 220 369 Q159 344 126 285 Q83 203 103 88 Q165 84 220 48"
          fill="url(#body)"
          stroke="#fff5fc"
          strokeWidth="5"
        />
        <path
          d="M133 115 Q169 106 192 88"
          fill="none"
          stroke="#fff"
          strokeWidth="10"
          strokeLinecap="round"
          opacity=".6"
        />
        <ellipse
          cx="165"
          cy="228"
          rx="22"
          ry="12"
          fill="#e58fb5"
          opacity=".7"
        />
        <ellipse
          cx="279"
          cy="228"
          rx="22"
          ry="12"
          fill="#e58fb5"
          opacity=".7"
        />
        <ellipse cx="179" cy="192" rx="10" ry={blink ? 2 : 16} fill="#443647" />
        <ellipse cx="261" cy="192" rx="10" ry={blink ? 2 : 16} fill="#443647" />
        <path
          d="M204 225 Q220 244 237 224"
          fill="none"
          stroke="#70465c"
          strokeWidth="6"
          strokeLinecap="round"
        />
        <path
          d="m197 285 17 17 33-38"
          fill="none"
          stroke="#fff5fc"
          strokeWidth="10"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
};
export const FeatureKeyword: React.FC<React.PropsWithChildren> = ({
  children,
}) => (
  <span
    style={{
      padding: "13px 25px",
      borderRadius: 50,
      background: "#ffffffbb",
      border: "1px solid #fff",
      fontSize: 30,
      display: "inline-block",
    }}
  >
    {children}
  </span>
);
export const LogoReveal: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <div
      style={{
        opacity: enter(f - 360),
        transform: `translateY(${(1 - enter(f - 360)) * 35}px)`,
      }}
    >
      <div style={{ fontSize: 138, fontWeight: 700, letterSpacing: -7 }}>
        Fall<span style={{ color: C.accent }}>Sense</span>
      </div>
      <p style={{ fontSize: 34, lineHeight: 1.6, maxWidth: 900 }}>
        Hệ thống hỗ trợ giám sát
        <br />
        và cảnh báo té ngã bằng camera
      </p>
      <FeatureKeyword>A Little Guardian.</FeatureKeyword>
    </div>
  );
};
export const BrowserFrame: React.FC<{ asset: string; width?: number }> = ({
  asset,
  width = 1380,
}) => (
  <div
    style={{
      width,
      borderRadius: 26,
      overflow: "hidden",
      boxShadow: "0 34px 85px #604d7429",
      border: "3px solid white",
      background: "white",
    }}
  >
    <div
      style={{
        height: 39,
        background: "#fbfaff",
        display: "flex",
        alignItems: "center",
        gap: 9,
        paddingLeft: 20,
      }}
    >
      {["#ecc7d6", "#e9d9b8", "#c3dccc"].map((c) => (
        <i
          key={c}
          style={{ width: 11, height: 11, borderRadius: 20, background: c }}
        />
      ))}
      <span style={{ marginLeft: width / 3, fontSize: 17, color: "#8d8190" }}>
        FallSense · Product tour
      </span>
    </div>
    <div style={{ position: "relative" }}>
      <Img
        src={staticFile(`assets/${asset}`)}
        style={{ width: "100%", display: "block" }}
      />
      {asset === "settings.jpg" && (
        <div
          style={{
            position: "absolute",
            left: "24%",
            right: "24%",
            top: "58%",
            bottom: "10%",
            background: "#f5eef8",
            borderRadius: 15,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 28,
            color: C.accent,
          }}
        >
          Thông tin liên hệ đã ẩn
        </div>
      )}
    </div>
  </div>
);
export const WebCarousel: React.FC = () => {
  const f = useCurrentFrame();
  const idx = Math.min(3, Math.floor((f - 1260) / 240));
  const local = (f - 1260) % 240;
  return (
    <>
      <div style={{ position: "absolute", left: 115, top: 70 }}>
        <div style={{ fontSize: 25, color: C.accent, letterSpacing: 5 }}>
          PRODUCT TOUR / 0{idx + 1}
        </div>
        <h1 style={{ fontSize: 64, margin: "14px 0" }}>
          {config.features[idx][0]}
        </h1>
        <FeatureKeyword>{config.features[idx][1]}</FeatureKeyword>
      </div>
      <div
        style={{
          position: "absolute",
          left: 255,
          top: 290,
          transform: `perspective(2200px) translateX(${(1 - enter(local)) * 180}px) rotateY(${interpolate(local, [0, 45], [12, 0], clamp)}deg)`,
          opacity: interpolate(local, [0, 20], [0, 1], clamp),
        }}
      >
        <BrowserFrame asset={config.screenshots[idx + 1]} width={1410} />
      </div>
      <div
        style={{
          position: "absolute",
          bottom: 38,
          left: 115,
          fontSize: 28,
          color: "#716678",
        }}
      >
        {config.features[idx][2]}
      </div>
    </>
  );
};
export const Intro: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <StudioStage>
      {f < 720 && (
        <>
          <div
            style={{
              position: "absolute",
              left: 150,
              top: 160,
              opacity: f < 350 ? enter(f) : 1,
            }}
          >
            {f < 360 ? (
              <>
                <div
                  style={{ fontSize: 25, letterSpacing: 5, color: C.accent }}
                >
                  FALLSENSE / A LITTLE GUARDIAN
                </div>
                <h1 style={{ fontSize: 102, lineHeight: 1.2, marginTop: 90 }}>
                  Một người
                  <br />
                  bạn nhỏ.
                </h1>
                <p style={{ fontSize: 32, color: "#716678" }}>
                  Đồng hành cùng sự an tâm.
                </p>
              </>
            ) : (
              <LogoReveal />
            )}
          </div>
          <div
            style={{
              position: "absolute",
              right: 190,
              top: 200,
              transform: `translateY(${(1 - enter(f)) * -370}px) scale(${interpolate(f, [320, 400], [1, 0.92], clamp)})`,
            }}
          >
            <Mascot3D size={610} />
          </div>
        </>
      )}
      {f >= 720 && f < 1260 && (
        <>
          <div style={{ position: "absolute", left: 110, top: 50 }}>
            <div style={{ color: C.accent, fontSize: 25, letterSpacing: 5 }}>
              GIAO DIỆN THẬT
            </div>
            <h1 style={{ fontSize: 64, margin: 10 }}>
              Một góc nhìn tổng quan.
            </h1>
          </div>
          <div
            style={{
              position: "absolute",
              left: 210,
              top: 220,
              transform: `perspective(2200px) rotateY(${interpolate(f, [720, 810], [15, 0], clamp)}deg) translateY(${(1 - enter(f - 720)) * 65}px)`,
            }}
          >
            <BrowserFrame asset="overview.jpg" width={1500} />
          </div>
          <div
            style={{
              position: "absolute",
              left: 125,
              bottom: 35,
              display: "flex",
              gap: 20,
            }}
          >
            {["Camera", "Giám sát", "Trạng thái · chưa khởi động"].map((x) => (
              <FeatureKeyword key={x}>{x}</FeatureKeyword>
            ))}
          </div>
        </>
      )}
      {f >= 1260 && f < 2220 && <WebCarousel />}
      {f >= 2220 && (
        <>
          <div
            style={{
              position: "absolute",
              left: 120,
              top: 90,
              opacity: interpolate(f, [2220, 2400], [1, 0], clamp),
              transform: `scale(${interpolate(f, [2220, 2400], [0.8, 0.2], clamp)})`,
            }}
          >
            {config.screenshots.slice(1).map((s, i) => (
              <div
                key={s}
                style={{
                  position: "absolute",
                  left: (i % 2) * 1000,
                  top: Math.floor(i / 2) * 530,
                }}
              >
                <BrowserFrame asset={s} width={850} />
              </div>
            ))}
          </div>
          <div
            style={{
              position: "absolute",
              right: 130,
              top: 150,
              opacity: interpolate(f, [2220, 2370], [1, 0], clamp),
            }}
          >
            <Mascot3D size={500} gesture="point" />
          </div>
          <AbsoluteFill
            style={{
              background: "radial-gradient(ellipse,#fff8fc,#EAF7FB)",
              opacity: interpolate(f, [2310, 2400], [0, 1], clamp),
            }}
          />
          <Sequence from={2400}>
            <AcademicSlide slide={slides[0]} index={0} handoff />
          </Sequence>
        </>
      )}
      <TimelineBar duration={introFrames} />
    </StudioStage>
  );
};
export const SourceFootnote: React.FC<{ text: string }> = ({ text }) => (
  <div
    style={{
      position: "absolute",
      bottom: 44,
      left: 110,
      right: 110,
      fontSize: 24,
      color: "#726878",
      lineHeight: 1.4,
    }}
  >
    {text}
  </div>
);
export const KpiCard: React.FC<{ text: string; index: number }> = ({
  text,
  index,
}) => {
  const f = useCurrentFrame();
  const [heading, ...body] = text.split("\n");
  const p = enter(f, index * 14);
  return (
    <div
      style={{
        flex: 1,
        padding: 35,
        minHeight: 240,
        borderRadius: 30,
        background: "#ffffffbd",
        border: "2px solid #fff",
        transform: `translateY(${(1 - p) * 35}px)`,
        opacity: p,
      }}
    >
      <div
        style={{
          fontSize: 38,
          fontWeight: 700,
          lineHeight: 1.4,
          color: index === 0 ? C.accent : C.ink,
        }}
      >
        {heading}
      </div>
      <div
        style={{
          fontSize: 30,
          lineHeight: 1.6,
          marginTop: 24,
          color: "#655d6c",
        }}
      >
        {body.join("\n")}
      </div>
    </div>
  );
};
export const PoseLandmarkDiagram: React.FC = () => (
  <svg viewBox="0 0 600 600" width="520" height="520">
    <circle cx="300" cy="75" r="38" fill={C.pink} />
    <g stroke={C.sage} strokeWidth="8" fill="none">
      <path d="M210 165H390L370 340H230ZM210 165 150 260 125 330M390 165 450 260 475 330M230 340 210 445 195 550M370 340 390 445 405 550" />
    </g>
    {[
      [210, 165, "11"],
      [390, 165, "12"],
      [230, 340, "23"],
      [370, 340, "24"],
      [210, 445, "25"],
      [390, 445, "26"],
      [195, 550, "27"],
      [405, 550, "28"],
    ].map(([x, y, t]) => (
      <g key={t}>
        <circle cx={x} cy={y} r="13" fill={C.accent} />
        <text x={Number(x) + 23} y={Number(y) + 9} fontSize="27" fill={C.ink}>
          {t}
        </text>
      </g>
    ))}
  </svg>
);
export const StateMachineDiagram: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <>
      <div
        style={{
          display: "flex",
          gap: 22,
          alignItems: "center",
          marginTop: 50,
        }}
      >
        {slides[11].items.map((s, i) => (
          <React.Fragment key={s}>
            <div
              style={{
                padding: "38px 32px",
                background: i === 2 ? C.pink : "#fff",
                borderRadius: 25,
                fontSize: 31,
                opacity: enter(f, i * 22),
              }}
            >
              {s}
            </div>
            {i < 3 && <span style={{ color: C.accent, fontSize: 40 }}>→</span>}
          </React.Fragment>
        ))}
      </div>
      <div style={{ display: "flex", gap: 20, marginTop: 45 }}>
        {[
          "Dữ liệu người / thân hợp lệ",
          "Bằng chứng tích lũy theo bước",
          "Bất động tích lũy theo giây",
        ].map((x) => (
          <KpiCard key={x} index={0} text={x} />
        ))}
      </div>
      <p style={{ fontSize: 30, color: C.accent }}>
        NO_PERSON / PARTIAL_POSE: chưa đủ dữ liệu · Modal mở từ FALLEN theo góp
        ý
      </p>
    </>
  );
};
export const AcademicSlide: React.FC<{
  slide: Slide;
  index: number;
  handoff?: boolean;
}> = ({ slide, index, handoff = false }) => {
  const f = useCurrentFrame();
  const p = enter(f);
  return (
    <AbsoluteFill style={{ padding: "85px 110px", opacity: handoff ? p : 1 }}>
      <div style={{ fontSize: 25, letterSpacing: 4, color: C.accent }}>
        {slide.eyebrow}
      </div>
      <h1
        style={{
          fontSize: slide.kind === "title" ? 76 : 70,
          lineHeight: 1.2,
          letterSpacing: -2,
          whiteSpace: "pre-line",
          margin: "28px 0 45px",
          maxWidth: 1550,
          transform: `translateY(${(1 - p) * 18}px)`,
        }}
      >
        {slide.title}
      </h1>
      {slide.kind === "title" ? (
        <>
          <div style={{ maxWidth: 1150 }}>
            {slide.items.map((s, i) => (
              <p
                key={s}
                style={{
                  fontSize: i === 0 ? 38 : 30,
                  lineHeight: 1.5,
                  whiteSpace: "pre-line",
                  color: i === 0 ? C.accent : "#625a69",
                }}
              >
                {s}
              </p>
            ))}
          </div>
          <div style={{ position: "absolute", right: 85, top: 230 }}>
            <Mascot3D size={475} frame={handoff ? f : f + 180} />
          </div>
        </>
      ) : slide.kind === "ui" ? (
        <div style={{ display: "flex", gap: 40 }}>
          <div style={{ position: "relative" }}>
            <BrowserFrame asset="live-monitor.jpg" width={1170} />
            {[
              [30, 30],
              [50, 50],
              [75, 32],
              [81, 40],
              [81, 27],
            ].map(([x, y], i) => (
              <div
                key={i}
                style={{
                  position: "absolute",
                  left: `${x}%`,
                  top: `${y}%`,
                  background: C.accent,
                  color: "white",
                  border: "3px solid white",
                  width: 42,
                  height: 42,
                  borderRadius: 40,
                  textAlign: "center",
                  fontSize: 27,
                  opacity: enter(f, i * 16),
                }}
              >
                {i + 1}
              </div>
            ))}
          </div>
          <div style={{ fontSize: 29, lineHeight: 1.6 }}>
            <FeatureKeyword>DEMO SIM</FeatureKeyword>
            {slide.items.map((s) => (
              <p key={s}>{s}</p>
            ))}
          </div>
        </div>
      ) : slide.kind === "pose" ? (
        <div style={{ display: "flex", gap: 110, alignItems: "center" }}>
          <PoseLandmarkDiagram />
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 15,
              flex: 1,
            }}
          >
            {slide.items.map((s, i) => (
              <div
                key={s}
                style={{
                  padding: 28,
                  background: "#ffffffbb",
                  borderRadius: 25,
                  fontSize: 32,
                  opacity: enter(f, i * 15),
                }}
              >
                {s}
              </div>
            ))}
          </div>
        </div>
      ) : slide.kind === "weights" || slide.kind === "example" ? (
        <div style={{ display: "flex", gap: 65 }}>
          <div style={{ width: 1120 }}>
            {featureNames.map((name, i) => (
              <div
                key={name}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 20,
                  marginBottom: 15,
                  fontSize: 30,
                }}
              >
                <div style={{ width: 330 }}>{name}</div>
                <div
                  style={{
                    width: 230,
                    height: 25,
                    background: "#ffffffbb",
                    borderRadius: 30,
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      height: "100%",
                      background: i % 2 ? C.accent : "#9e8ec0",
                      width: `${(weights[i] / 0.22) * 100 * enter(f, i * 9)}%`,
                    }}
                  />
                </div>
                <div>
                  {slide.kind === "example"
                    ? `${example[i].toFixed(2)} × ${weights[i].toFixed(2)} = ${(example[i] * weights[i]).toFixed(3)}`
                    : weights[i].toFixed(2)}
                </div>
              </div>
            ))}
          </div>
          <div style={{ flex: 1 }}>
            {slide.items.map((s) => (
              <p key={s} style={{ fontSize: 33, lineHeight: 1.6 }}>
                {s}
              </p>
            ))}
            <div style={{ fontSize: 85, fontWeight: 700, color: C.accent }}>
              {slide.kind === "example" ? "0,521" : "1,00"}
            </div>
          </div>
        </div>
      ) : slide.kind === "states" ? (
        <StateMachineDiagram />
      ) : slide.kind === "flow" ? (
        <div style={{ position: "relative", marginTop: 90 }}>
          <div style={{ display: "flex", gap: 22 }}>
            {slide.items.map((s, i) => (
              <React.Fragment key={s}>
                <KpiCard text={s} index={i} />
                {i < 4 && (
                  <div
                    style={{
                      alignSelf: "center",
                      fontSize: 35,
                      color: C.accent,
                    }}
                  >
                    →
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
          <div
            style={{
              position: "absolute",
              top: -36,
              left: `${((f % 240) / 240) * 94}%`,
              width: 18,
              height: 18,
              borderRadius: 20,
              background: C.accent,
            }}
          />
          <p style={{ fontSize: 31, color: "#716678", marginTop: 65 }}>
            Một khung hình chưa đủ — cần theo dõi diễn biến theo thời gian.
          </p>
        </div>
      ) : (
        <div style={{ display: "flex", gap: 30, marginTop: 80 }}>
          {slide.items.map((s, i) => (
            <KpiCard key={s} text={s} index={i} />
          ))}
        </div>
      )}
      <SourceFootnote text={slide.source} />
      <div
        style={{
          position: "absolute",
          right: 55,
          top: 55,
          fontSize: 25,
          color: "#8b7e93",
        }}
      >
        FallSense / {String(index + 1).padStart(2, "0")}
      </div>
    </AbsoluteFill>
  );
};
export const TimelineBar: React.FC<{ duration: number }> = ({ duration }) => {
  const f = useCurrentFrame();
  return (
    <div
      style={{
        position: "absolute",
        bottom: 0,
        height: 5,
        background: C.accent,
        width: `${(f / duration) * 100}%`,
      }}
    />
  );
};
export const Presentation: React.FC<{ skipTitle?: boolean }> = ({
  skipTitle = false,
}) => (
  <StudioStage>
    {slides.map((s, i) => {
      const from = slideFrames
        .slice(skipTitle ? 1 : 0, i)
        .reduce((a, b) => a + b, 0);
      return skipTitle && i === 0 ? null : (
        <Sequence key={i} from={from} durationInFrames={slideFrames[i]}>
          <AcademicSlide slide={s} index={i} />
        </Sequence>
      );
    })}
    <TimelineBar
      duration={presentationFrames - (skipTitle ? slideFrames[0] : 0)}
    />
  </StudioStage>
);
export const AudioTimeline: React.FC<{introMusic?:boolean}> = ({introMusic=true}) => {
  const {durationInFrames:duration,fps}=useVideoConfig();
  const musicFrames=Math.min(introFrames,duration);
  if(config.audio.mute)return null;
  return <>
    {introMusic && config.audio.music && <Sequence durationInFrames={musicFrames}>
      <Audio src={staticFile(config.audio.music)} volume={f=>Math.max(0,Math.min(1,
        f/(config.audio.fadeInSeconds*fps),
        (musicFrames-f)/(config.audio.fadeOutSeconds*fps)))*config.audio.musicGain}/>
    </Sequence>}
    {(["voiceover","sfx"] as const).map(k=>config.audio[k]?<Audio key={k}
      src={staticFile(config.audio[k])} volume={f=>Math.max(0,Math.min(1,f/fps,(duration-f)/fps))*config.audio.voiceoverGain}/>:null)}
  </>;
};
const Full: React.FC = () => (
  <>
    <Sequence durationInFrames={introFrames}>
      <Intro />
    </Sequence>
    <Sequence
      from={introFrames}
      durationInFrames={presentationFrames - slideFrames[0]}
    >
      <Presentation skipTitle />
    </Sequence>
    <AudioTimeline />
  </>
);
const IntroWithAudio: React.FC = () => (
  <>
    <Intro />
    <AudioTimeline />
  </>
);
const PresentationWithAudio: React.FC = () => (
  <>
    <Presentation />
    <AudioTimeline introMusic={false} />
  </>
);
export const Root: React.FC = () => (
  <>
    {[
      ["FallSenseIntro", IntroWithAudio, introFrames],
      ["FallSensePresentation", PresentationWithAudio, presentationFrames],
      [
        "FallSenseFullShow",
        Full,
        introFrames + presentationFrames - slideFrames[0],
      ],
    ].map(([id, component, duration]) => (
      <Composition
        key={id as string}
        id={id as string}
        component={component as React.FC}
        durationInFrames={duration as number}
        fps={config.fps}
        width={config.width}
        height={config.height}
      />
    ))}
  </>
);
