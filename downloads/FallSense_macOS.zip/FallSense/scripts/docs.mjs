import ts from "typescript";
import { readFile, writeFile, mkdir } from "node:fs/promises";
await mkdir("out", {recursive:true});
const code = ts.transpileModule(await readFile("src/config.ts", "utf8"), {
  compilerOptions: { module: ts.ModuleKind.ESNext },
}).outputText;
const { config, slides, weights, example } = await import(
  "data:text/javascript;base64," + Buffer.from(code).toString("base64")
);
const stamp = (s) =>
  `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
let time = 40;
const srt = [];
const notes = slides.map((s, i) => {
  const start = i === 0 ? 40 : time;
  const duration = i === 0 ? 3 : config.slideSeconds[i];
  if (i === 0) time = 43;
  else time += duration;
  srt.push(
    `${i + 1}\n${stamp(start).replace(":", ":")},000 --> ${stamp(start + duration)},000\n${s.title.replaceAll("\n", " ")}\n`,
  );
  return `## ${i + 1}. ${stamp(start)}–${stamp(start + duration)} · ${s.title.replaceAll("\n", " ")}\n\n${s.items.join(" · ")}\n\nLời dẫn đề xuất: ${s.note}\n\nNguồn: ${s.source}\n`;
});
await writeFile(
  "NARRATION_SCRIPT.md",
  "# Lời dẫn và cue sheet\n\nĐây là lời dẫn đề xuất, chưa thu âm; không phải phiên âm video. Cue theo FullShow, title bắt đầu tại 00:40 và chuyển slide 2 tại 00:43.\n\n" +
    notes.join("\n"),
);
await writeFile(
  "out/FallSense.srt",
  srt.map((s) => s.replace(/(\d\d:\d\d),/g, "00:$1,")).join("\n"),
);
const score = weights.reduce((a, w, i) => a + w * example[i], 0);
if (
  Math.abs(score - 0.521) > 1e-10 ||
  Math.abs(weights.reduce((a, b) => a + b, 0) - 1) > 1e-10 ||
  slides.length !== 13 ||
  config.slideSeconds.length !== 13
)
  throw Error("Content contract failed");
await writeFile(
  "out/timing.json",
  JSON.stringify({
    introSeconds: config.introSeconds,
    audio: config.audio,
    fullSeconds: time,
    fps: config.fps,
    width: config.width,
    height: config.height,
  }),
);
console.log({
  slides: slides.length,
  weightSum: 1,
  exampleScore: score,
  fullSeconds: time,
});
