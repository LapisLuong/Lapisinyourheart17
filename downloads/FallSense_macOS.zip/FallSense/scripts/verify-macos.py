import json
import subprocess
from pathlib import Path

results = []
for name, frames in [('Intro', 2580), ('FullShow', 13440)]:
    path = Path(f'out/macOS/FallSense_{name}_Mac.mp4')
    info = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-count_frames', '-show_streams', '-show_format', '-of', 'json', str(path)], text=True))
    video = next(s for s in info['streams'] if s['codec_type'] == 'video')
    audio = next(s for s in info['streams'] if s['codec_type'] == 'audio')
    assert video['codec_name'] == 'h264' and video['pix_fmt'] == 'yuv420p'
    assert video['color_range'] == 'tv' and video['color_space'] == 'bt709'
    assert video['width'] == 1920 and video['height'] == 1080
    assert video['r_frame_rate'] == '60/1' and int(video['nb_read_frames']) == frames
    assert audio['codec_name'] == 'aac' and audio['sample_rate'] == '48000' and audio['channels'] == 2
    assert abs(float(info['format']['duration']) - frames / 60) < .05
    subprocess.run(['ffmpeg', '-v', 'error', '-xerror', '-i', str(path), '-f', 'null', '-'], check=True)
    with path.open('rb') as f:
        header = f.read(1024 * 1024)
    assert header.find(b'moov') >= 0 and header.find(b'moov') < header.find(b'mdat')
    results.append({'file': str(path), 'frames': frames, 'seconds': frames/60, 'codec':'h264', 'pixelFormat':'yuv420p','audio':'AAC 48kHz stereo', 'fastStart':True,'fullDecode':'passed','nativeMacTest':False})
Path('docs/validation/macos-validation.json').write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
