import {resolveBrowser, renderConcurrency} from "./browser.mjs";
import { bundle } from "@remotion/bundler";
import { selectComposition, renderStill } from "@remotion/renderer";
import { mkdir, writeFile } from "node:fs/promises";
const serveUrl = await bundle({ entryPoint: "src/index.ts" });
const browserExecutable = resolveBrowser();
const composition = await selectComposition({
  serveUrl,
  id: "FallSenseFullShow",
  browserExecutable,
});
await mkdir("out/qa", { recursive: true });
const durations = [10, 15, 12, 14, 15, 15, 14, 14, 14, 17, 17, 18, 16];
const frames = new Set([
  0, 60, 180, 360, 720, 1200, 1800, 2520, 2220, 2340, 2400, 2579,
]);
let cursor = 2580;
for (let i = 1; i < 13; i++) {
  frames.add(cursor);
  frames.add(cursor + 60);
  cursor += durations[i] * 60;
  frames.add(cursor - 1);
}
for (const frame of [...frames].sort((a, b) => a - b)) {
  await renderStill({
    serveUrl,
    composition,
    frame,
    output: `out/qa/${String(frame).padStart(5, "0")}.jpg`,
    imageFormat: "jpeg",
    browserExecutable,
    scale: 0.5,
  });
  console.log(`QA ${frame}`);
}
await writeFile(
  "out/qa/manifest.json",
  JSON.stringify(
    {
      composition: composition.id,
      frames: [...frames],
      width: composition.width,
      height: composition.height,
      fps: composition.fps,
      durationInFrames: composition.durationInFrames,
    },
    null,
    2,
  ),
);
