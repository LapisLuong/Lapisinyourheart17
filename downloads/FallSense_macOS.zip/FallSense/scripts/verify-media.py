"""Verify actual video streams and decode complete output (not just file existence)."""
import json
import subprocess
from pathlib import Path

timing = json.loads(Path('out/timing.json').read_text())
results = []
for filename, seconds in [('FallSense_Intro.mp4', timing['introSeconds']), ('FallSense_FullShow.mp4', timing['fullSeconds'])]:
    path = Path('out') / filename
    metadata = json.loads(subprocess.check_output([
        'ffprobe', '-v', 'error', '-count_frames', '-show_entries',
        'format=duration:stream=codec_name,codec_type,width,height,r_frame_rate,nb_read_frames,pix_fmt',
        '-of', 'json', str(path)
    ], text=True))
    stream = next(s for s in metadata['streams'] if s['codec_type'] == 'video')
    assert stream['codec_name'] == 'h264', metadata
    assert (stream['width'], stream['height']) == (timing['width'], timing['height']), metadata
    assert stream['r_frame_rate'] == str(timing['fps']) + '/1', metadata
    assert int(stream['nb_read_frames']) == seconds * timing['fps'], metadata
    assert abs(float(metadata['format']['duration']) - seconds) < .05, metadata
    subprocess.run(['ffmpeg', '-v', 'error', '-xerror', '-i', str(path), '-f', 'null', '-'], check=True)
    results.append({'file': str(path), 'status': 'passed', 'metadata': metadata, 'fullDecode': True})
Path('out/media-validation.json').write_text(json.dumps(results, indent=2))
print(json.dumps(results, indent=2))
