import {resolveBrowser, renderConcurrency} from "./browser.mjs";
import ts from "typescript";
import {dirname} from "node:path";
import { readFile, mkdir } from "node:fs/promises";
import { bundle } from "@remotion/bundler";
import { selectComposition, renderMedia } from "@remotion/renderer";
const [id = "FallSenseIntro", output = "out/FallSense_Intro.mp4", ...flags] =
  process.argv.slice(2);
const configCode = ts.transpileModule(await readFile("src/config.ts", "utf8"), {
  compilerOptions: { module: ts.ModuleKind.ESNext },
}).outputText;
const { config } = await import(
  "data:text/javascript;base64," + Buffer.from(configCode).toString("base64")
);
await mkdir(dirname(output), {recursive:true});
const serveUrl = await bundle({ entryPoint: "src/index.ts" });
const browserExecutable = resolveBrowser();
const composition = await selectComposition({
  serveUrl,
  id,
  browserExecutable,
});
let last = -1;
await renderMedia({
  serveUrl,
  composition,
  codec: "h264",
  pixelFormat: "yuv420p",
  colorSpace: "bt709",
  outputLocation: output,
  browserExecutable,
  muted: config.audio.mute || flags.includes("--silent"),
  frameRange: flags.includes("--smoke") ? [0, 59] : undefined,
  concurrency: renderConcurrency,
  crf: 20,
  scale: flags.includes("--scale=0.5") ? 0.5 : 1,
  onProgress: (p) => {
    const n = Math.floor(p.progress * 10);
    if (n !== last) {
      console.log(`${id}: ${n * 10}%`);
      last = n;
    }
  },
});
console.log(`Rendered ${output}`);
