"""Mix supplied soundtrack over intro only, reusing rendered video without re-encoding."""
import json
import subprocess
from pathlib import Path

cfg = json.loads(Path('out/timing.json').read_text())
audio = cfg['audio']
intro = cfg['introSeconds']
for name, duration in [('Intro', intro), ('FullShow', cfg['fullSeconds'])]:
    fade_start = intro - audio['fadeOutSeconds']
    filters = (f"[1:a]atrim=0:{intro},asetpts=PTS-STARTPTS,volume={audio['musicGain']},"
               f"afade=t=in:st=0:d={audio['fadeInSeconds']},"
               f"afade=t=out:st={fade_start}:d={audio['fadeOutSeconds']},"
               f"apad=whole_dur={duration}[music]")
    subprocess.run(['ffmpeg', '-y', '-v', 'error',
                    '-i', f'out/FallSense_{name}_Silent.mp4',
                    '-i', str(Path('public') / audio['music']),
                    '-filter_complex', filters, '-map', '0:v:0', '-map', '[music]',
                    '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000',
                    '-t', str(duration), '-movflags', '+faststart',
                    f'out/FallSense_{name}.mp4'], check=True)
    print(f'Mixed {name}: soundtrack 0–{intro}s; gain {audio["musicGain"]}; fade-in/out configured')
