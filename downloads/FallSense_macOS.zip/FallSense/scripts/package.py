"""Package editable project, references and docs; exclude caches and video builds."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent.parent
(root / 'out').mkdir(exist_ok=True)
files = [f for f in root.iterdir() if f.is_file() and (f.suffix in {'.md', '.json'} or f.name == '.gitignore')]
for folder in ['src', 'scripts', 'public', 'docs', 'references', 'macOS']:
    files.extend(p for p in (root / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
with ZipFile(root / 'out/FallSense_Project.zip', 'w', ZIP_DEFLATED) as archive:
    for path in sorted(files):
        archive.write(path, 'FallSense/' + path.relative_to(root).as_posix())
print(f'Packaged {len(files)} files')
