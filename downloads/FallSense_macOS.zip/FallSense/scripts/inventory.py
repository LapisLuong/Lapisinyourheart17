"""Extract source-deck text and notes without executing embedded content."""
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parent.parent
out = root / 'docs'
out.mkdir(exist_ok=True)
for deck in (root / 'references').glob('*.pptx'):
    sections = []
    slides = 0
    with ZipFile(deck) as archive:
        names = [n for n in archive.namelist() if re.fullmatch(
            r'ppt/(slides/slide\d+|notesSlides/notesSlide\d+)\.xml', n)]
        for name in sorted(names, key=lambda n: ('notes' in n, int(re.search(r'(\d+)\.xml', n)[1]))):
            slides += '/slides/' in name
            text = [t.text or '' for t in ET.fromstring(archive.read(name)).iter(
                '{http://schemas.openxmlformats.org/drawingml/2006/main}t')]
            sections.append('## ' + name + '\n\n' + '\n\n'.join(text))
    (out / (deck.stem + '_EXTRACTED.md')).write_text(
        '# ' + deck.name + '\n\n' + '\n\n'.join(sections))
    print(f'{deck.name}: {slides} slides; text and notes extracted')
