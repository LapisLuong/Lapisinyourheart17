"""Package source archive plus QuickTime-friendly video exports."""
from pathlib import Path
from zipfile import ZipFile, ZIP_STORED
import subprocess

root = Path(__file__).resolve().parent.parent
subprocess.run(['python', 'scripts/package.py'], cwd=root, check=True)
with ZipFile(root / 'out/FallSense_Project.zip') as source, ZipFile(root / 'out/FallSense_macOS.zip', 'w') as dest:
    for info in source.infolist():
        dest.writestr(info, source.read(info.filename))
    for name in ['FallSense_Intro_Mac.mp4', 'FallSense_FullShow_Mac.mp4']:
        dest.write(root / 'out/macOS' / name, 'FallSense/Videos/' + name, compress_type=ZIP_STORED)
    dest.write(root / 'out/FallSense.srt', 'FallSense/Videos/FallSense.srt')
    assert dest.testzip() is None
print('Created out/FallSense_macOS.zip')
