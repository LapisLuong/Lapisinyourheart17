# QA — FallSense

## Kiểm tra đã thực hiện

- `npm run typecheck`: TypeScript strict, pass sau khi khai báo đầy đủ API FontFaceSet.
- `node scripts/docs.mjs`: 13 slide, 13 timing, tổng trọng số 1.00 và phép tính ví dụ 0.521, pass.
- `npm run qa`: render headless Chromium các mốc 0s, 6s, 12s, 20s, 30s, 42s; thêm pose/mascot và handoff; mỗi slide 2–13 có đầu, +1s, cuối. Manifest `out/qa/manifest.json`.
- Đã xem contact sheet toàn bộ khung QA để kiểm tra cắt chữ/bố cục: không thấy clipping ở các khung đã xem. Không phải kiểm tra mọi khung hình.
- Đã xem cả 5 ảnh gốc: không thấy địa chỉ email rõ trong ảnh được cấp; vẫn thêm mask kín toàn vùng liên hệ Settings để bảo vệ output.
- Ảnh Live Monitor có DEMO SIM; nội dung nhắc rõ điểm số không phải xác suất; không dùng FPS trên ảnh làm số đo sản phẩm.
- `ffprobe` video đầu vào: H.264, 2556×1300, 15s, không audio stream. Đã xem khung tại 5s; chưa xem trọn video và không chạy transcription.
- Trích XML PPTX: 10 slide gốc, 18 trang góp ý; trích notes nguyên văn trong `docs/`.

## Phạm vi và giới hạn

Nguồn UI và cảnh báo chỉ là tư liệu được cấp; chưa có app source. Không thử camera/email/FSM thực tế, không đo accuracy, latency hoặc sensitivity. Chi tiết ngưỡng và timing ứng dụng được gắn nhãn theo góp ý/chưa xác minh. Đã ghép nhạc người dùng chọn vào intro 43s; chưa có narration. Giữ các bản silent riêng.

Mascot dùng fallback 2.5D có chủ đích; chưa thử R3F. Bản dựng chưa đạt toàn bộ chuyển động 3D và shield morph trong prompt; xem `NEXT_STEPS.md`. Nội dung trong screenshot gốc nhỏ hơn chữ slide; hero panel được đưa chính diện, callout bên ngoài dùng cỡ ≥30px. Footnote dùng 24px; cần kiểm tra màn chiếu thực trước trình bày chính thức.

- `npm ci` trong `/tmp/fallsense-repro` (thư mục sạch): pass, xác nhận lockfile có thể cài lại.
- `npm ls --depth=0`: dependency versions và peer tree hợp lệ.
- Remotion Studio đã khởi động và trả HTTP 200; composition đã render được trong Chromium.
- Smoke render 1 giây với cấu hình mute: H.264, 1080p, không audio stream.

## Kết quả xuất video

| File | Video | Số frame | Thời lượng | Audio | Kết quả |
|---|---|---:|---:|---|---|
| FallSense_Intro.mp4 | H.264 1920×1080, 60 FPS | 2.580 | 43,000s | AAC stereo 48kHz | ffprobe + full decode pass |
| FallSense_FullShow.mp4 | H.264 1920×1080, 60 FPS | 13.440 | 224,000s | AAC stereo 48kHz | ffprobe + full decode pass |

Các bản `_Silent.mp4` giữ nguyên hình, không có audio. Bản phối dùng stream copy video nên không giảm chất lượng hình. Xác nhận segment 2–5s có nhạc (peak −11,9dB), segment 45–48s im lặng (peak −91dB). Smoke Remotion có nhạc đã render thành công; cấu hình nhạc được lưu trong source để tái render.

Chi tiết kiểm tra lưu `out/media-validation.json`, `out/audio-validation.json`, `out/audio-metadata.json`; bản sao trong `docs/validation/` đi cùng ZIP mã nguồn. Có 48 ảnh QA ở `out/qa/`; đã kiểm tra contact sheet, không tuyên bố xem lại toàn bộ video theo thời gian thực. Studio, source, video và archive được xác nhận trong phiên này; chưa push GitHub hoặc publish environment.

## Gói macOS

- Browser resolver đã kiểm tra các nhánh Mac có Chrome, Mac không có Chrome (Remotion tự tải), override hợp lệ/không tồn tại và Linux.
- Ba file `.command` qua kiểm tra cú pháp `bash -n`; dependency dùng `npm ci` trên máy đích, không đóng gói binary Linux.
- TypeScript pass; smoke render bằng resolver mới thành công với H.264/AAC.
- Hai bản video Mac được đổi sang H.264 yuv420p, BT.709/video range, AAC stereo 48kHz, fast-start. Kiểm tra số frame, thời lượng và giải mã toàn bộ bằng `scripts/verify-macos.py`; kết quả nằm ở `docs/validation/macos-validation.json`.
- Không có máy macOS 27 trong phiên này: chưa xác nhận trực tiếp QuickTime/Finder hoặc render native trên phiên bản OS đó. Hướng dẫn sử dụng trong `MACOS.md`.
