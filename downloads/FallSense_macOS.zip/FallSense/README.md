# FallSense — A Little Guardian

Dự án Remotion / React / TypeScript: intro 43 giây và bài trình bày tiếng Việt 13 slide. 1920×1080, 60 FPS, H.264. Mascot nguyên bản dùng 2.5D có gradient khối, vẫy tay, chớp mắt và nhún; chưa phải mô hình 3D GLB.

## Chạy và render

Hướng dẫn cho Mac: xem `MACOS.md` và các file nhấp đúp trong `macOS/`.

Yêu cầu Node.js 22+ và Chromium. Đã kiểm tra trên Node 24.19.0, Chromium hệ thống tại `/usr/bin/chromium`. Tự chọn browser theo hệ điều hành; có thể đặt `CHROME_PATH` để chỉ định browser.

```sh
npm ci --cache /workspace/.npm-cache
npm run typecheck
npm run studio
npm run qa
npm run render:intro
npm run render:full
npm run render:preview
node scripts/docs.mjs
python scripts/verify-media.py
python scripts/package.py
```

Dùng checkout hiện tại; tác vụ cloud đã được cô lập nên không cần tạo Git worktree. `src/config.ts` chứa màu, thời lượng, ảnh, nội dung, ghi chú, cấu hình audio và 13 thời lượng slide. Đường dẫn media tương đối với `public/`. Composition `FallSensePresentation` có đủ 13 slide độc lập; FullShow dùng title trong 3 giây cuối intro, rồi chuyển slide 2 để tránh lặp title. Tổng FullShow mặc định 224 giây. Preview giảm kích thước xuống 960×540, vẫn 60 FPS.

Nhạc nền từ file người dùng bổ sung đã cấu hình tại `public/audio/user-supplied.m4a`: chỉ phát ở 0–43 giây phần mở đầu, gain 0,4, fade-in 1,2 giây và fade-out 3 giây. Phần học thuật sau 43 giây không nhạc. `audio.mute` tắt toàn bộ audio; `render:preview` luôn không tiếng. Voiceover/SFX có track riêng nhưng chưa được cung cấp. Không có phiên âm hoặc tự nhận diện beat; xem `docs/AUDIO_CUES.md`.

`python scripts/inventory.py` trích lại text và notes từ hai PPTX gốc trong `references/`. `python scripts/verify-media.py` dùng FFmpeg/FFprobe để kiểm tra đủ frame và giải mã toàn bộ hai MP4 đã render.

## Tài liệu và giới hạn

- `CONTENT_AUDIT.md`: xung đột nội dung và bản đồ 13 slide.
- `docs/*_EXTRACTED.md`: nguyên văn text/notes từ PPTX; không hiển thị trực tiếp tài liệu góp ý như slide.
- `STORYBOARD.md`, `NARRATION_SCRIPT.md`, `SOURCES.md`, `THIRD_PARTY_ASSETS.md`, `QA_REPORT.md`.
- `out/`: video, phụ đề cue, khung hình QA và log; không đưa video nặng vào Git.

Không có source ứng dụng FallSense trong bộ cung cấp. Không kiểm thử camera, phát hiện ngã, email hoặc hiệu quả lâm sàng. Các ngưỡng và timing ứng dụng là thông tin dẫn từ ghi chú góp ý, được đánh dấu chưa xác minh source. Video tham chiếu 15 giây không có audio, là UI DEMO SIM. Không dùng video này làm bằng chứng độ chính xác. MP4 không phải PowerPoint chỉnh sửa được; mã nguồn và config có thể chỉnh sửa.


`npm run render:intro:silent` và `npm run render:full:silent` tạo hai bản không tiếng. Khi đã có hai bản `_Silent.mp4`, có thể cập nhật bản phối âm nhanh mà không render lại hình:

```sh
node scripts/docs.mjs
python scripts/mix-audio.py
python scripts/verify-media.py
```

Bản nhạc được dùng theo yêu cầu người dùng cho bản dựng này; quyền tái sử dụng công khai chưa được xác minh.
