# Dùng FallSense trên macOS

## Chỉ xem video — không cần cài phần mềm

Trong gói `FallSense_macOS.zip`, mở thư mục `Videos` rồi nhấp đúp MP4 để xem bằng QuickTime Player. Video đã chuyển sang H.264, pixel format yuv420p, màu BT.709/video range, AAC stereo 48kHz và fast-start. Giữ 1920×1080, 60 FPS, thời lượng 43s / 224s; nhạc chỉ nằm trong phần mở đầu.

## Chỉnh sửa và render

1. Giải nén toàn bộ ZIP ra thư mục có quyền ghi, chẳng hạn Documents. Không chạy dự án trực tiếp trong cửa sổ xem trước ZIP.
2. Cài Node.js 22 hoặc 24 LTS từ https://nodejs.org/ nếu máy chưa có. Bước cài đầu cần Internet để tải dependency và có thể tải trình duyệt render.
3. Trong `macOS`, nhấp đúp `Open_FallSense.command` để mở Studio. Sửa nội dung ở `src/config.ts`.
4. Nhấp đúp `Render_Intro.command` hoặc `Render_FullShow.command` để xuất MP4 mới vào `out`.

Nếu Finder không chạy file `.command`, mở Terminal, vào thư mục dự án rồi chạy:

```sh
bash macOS/Open_FallSense.command
# hoặc
bash macOS/Render_FullShow.command
```

Không cần tắt cơ chế bảo vệ hệ thống. Nếu chỉ thiếu quyền executable, có thể dùng cách chạy bằng `bash` ở trên.

Trên Mac, chương trình tự tìm Google Chrome/Chromium trong Applications; nếu không có, Remotion dùng cơ chế tải browser mặc định. Có thể đặt `CHROME_PATH` nếu Chrome được cài ở nơi khác. Không còn phụ thuộc đường dẫn Chromium của Linux. Số worker giới hạn tối đa 4, để lại một core khi máy cho phép; phù hợp cả Apple Silicon và Intel có toolchain được dependency hỗ trợ.

Gói được chuẩn bị và kiểm tra định dạng trên Linux, chưa thử trực tiếp trên máy chạy macOS 27. Không có binary Linux hoặc `node_modules` được mang sang Mac: `npm ci` cài dependency đúng kiến trúc máy đích.

`QA_REPORT.md` và `NEXT_STEPS.md` ghi các giới hạn nội dung/3D của bản dựng. Không cần FFmpeg để xem video hoặc render bằng Remotion; FFmpeg CLI chỉ cần cho các script kiểm tra/phối âm Python tùy chọn.
