# Kiểm toán nội dung

Đã đọc trực tiếp XML text/notes của 10 slide gốc và 18 trang góp ý. Không có app-source, ba PDF hoặc `FINAL 4` được ghi chú nhắc tới. Các ghi chú nói đã đọc `nhom.zip` là lời của người biên soạn tài liệu, không phải việc tác vụ này đã thực hiện. Bản trích nguyên văn lưu trong `docs/`; nguồn gốc không bị ghi đè.

| Chủ đề | Xung đột / rủi ro | Cách trình bày | Mức xác minh |
|---|---|---|---|
| Số slide | Tên file 13slide nhưng thực tế 10 | Thêm khung bao, ví dụ, demo/giới hạn thành 13 | Đã đếm XML |
| Cảnh báo | Bài gốc: 15s rồi modal 15s, trình quay số | Theo góp ý: modal từ FALLEN; email thử sau countdown; không gọi cấp cứu | Dẫn ghi chú góp ý 7; chưa kiểm tra app |
| WHO | Gốc có ghi chú về số mới năm 2026 | Giữ 684.000, ghi rõ WHO 2021; số mới chưa xác minh, không đưa vào slide | Có trong nguồn được cấp; chưa duyệt web |
| Fleming | Dễ hiểu nhầm tỷ lệ cộng đồng | 53/66, 20/66, người >90 tuổi đã ngã | Đối chiếu hai deck, URL BMJ |
| Giao diện | Bài gốc là hình minh họa | Dùng ảnh thật được cấp, nhãn DEMO SIM | Quan sát ảnh và 1 khung video |
| Fall Score | UI có phần trăm và vạch .60; tài liệu nói ngưỡng .68 | Không suy diễn UI thành xác suất; giữ số kỹ thuật ở mức tài liệu | Xung đột .60/.68 chưa giải quyết; cần source phiên demo |
| Ngưỡng .75 / 1.30 | Không có source hiện hành | Ghi tọa độ chuẩn hóa, ngưỡng tham khảo | Góp ý 10, chưa xác minh source |
| Trọng số | 7 trọng số nhất quán | Tổng 1.00, ví dụ giả định .521 | Tính lại bằng script |
| Bộ đếm | “4 khung liên tiếp” quá tuyệt đối | Phân biệt bước tích lũy và giây | Góp ý 13–14, chưa xác minh source |
| Chất lượng | Gốc nói cần thấy chân | Chỉ nói dữ liệu thân tin cậy, chi tiết trong notes | Góp ý 9, chưa xác minh source |
| Demo | Danh sách thử nghiệm không phải kết quả | Hiện kế hoạch và giới hạn, không số đo bịa | Chưa chạy app |

## Bản đồ 13 slide

1–8: hiệu chỉnh slide gốc 1–8. 9: thêm khung bao từ góp ý 10. 10: gốc 9 + góp ý 11. 11: ví dụ giả định từ góp ý 12. 12: gốc 10 + góp ý 13–14. 13: kế hoạch demo và giới hạn từ góp ý 16.

## Quyết định cần dữ liệu tiếp theo

Cần source app đúng phiên bản để giải quyết vạch .60 trên ảnh so với .68 trong tài liệu, kiểm chứng countdown, classifier và gửi email. Không chặn việc dựng video học thuật với nhãn dẫn nguồn thận trọng.
