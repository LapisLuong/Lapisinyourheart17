# Nguồn nội dung

Nguồn trực tiếp đã đọc: hai PPTX người dùng cung cấp (10 slide bài gốc, 18 trang góp ý), năm JPG, metadata video 15s và khung hình tại 5s. File bổ sung 65s có AAC stereo 44,1 kHz, được người dùng chọn làm nhạc nền intro; đã tách audio và đo loudness bằng FFmpeg. Bản trích nội dung/notes lưu `docs/`. Chưa có source ứng dụng để đối chiếu và chưa truy cập nội dung đầy đủ các bài báo dưới đây; URL được giữ từ tài liệu đầu vào.

- WHO, Falls (dữ liệu được bài gốc ghi năm 2021): https://www.who.int/news-room/fact-sheets/detail/falls
- WHO, Step Safely (2021): https://www.who.int/teams/social-determinants-of-health/safety-and-mobility/step-safely
- Fleming J, Brayne C. BMJ 2008;337:a2227. DOI https://doi.org/10.1136/bmj.a2227 · https://www.bmj.com/content/337/bmj.a2227
- Google AI Edge, Pose Landmarker: https://ai.google.dev/edge/mediapipe/solutions/vision/pose_landmarker
- BlazePose, arXiv:2006.10204: https://arxiv.org/abs/2006.10204
- Trần Thị Hồng Ân và cs. 2017: https://doi.org/10.22144/ctu.jsi.2017.001 (chỉ được ghi chú góp ý nhắc tới; PDF không có).
- Remotion: https://www.remotion.dev/docs/ · https://www.remotion.dev/license

Không đưa accuracy của nghiên cứu khác thành kết quả FallSense. Ghi chú gốc nói WHO cập nhật 2026 chưa được xác minh trực tiếp, nên giữ mốc 2021 có nhãn năm.
