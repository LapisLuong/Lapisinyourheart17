# Lời dẫn và cue sheet

Đây là lời dẫn đề xuất, chưa thu âm; không phải phiên âm video. Cue theo FullShow, title bắt đầu tại 00:40 và chuyển slide 2 tại 00:43.

## 1. 00:40–00:43 · Giới thiệu ngành Công nghệ thông tin

FallSense — Hệ thống hỗ trợ giám sát
và cảnh báo té ngã bằng camera · TS. Nguyễn Tấn Hoàng Phước · Trường Đại học Công nghệ Thông tin – ĐHQG-HCM

Lời dẫn đề xuất: Giới thiệu sản phẩm học tập FallSense. Tên học phần và giảng viên được giữ theo slide gốc.

Nguồn: Bài gốc, slide 1

## 2. 00:43–00:58 · Khi một cú ngã không được nhận ra

684.000 ca tử vong/năm
Ước tính toàn cầu · WHO 2021 · 53/66 không tự đứng dậy
Sau ít nhất một lần ngã (~80%) · 20/66 nằm sàn ≥ 1 giờ
Trong nhóm đã ngã (~30%)

Lời dẫn đề xuất: Fleming & Brayne nghiên cứu người trên 90 tuổi: 110 người tham gia, 66 người đã ngã. Không khái quát tỷ lệ cho cộng đồng. Giữ số liệu WHO 2021; thông tin cập nhật WHO trong ghi chú gốc chưa được xác minh trực tiếp.

Nguồn: WHO (2021), Falls · Fleming & Brayne (2008), BMJ 337:a2227

## 3. 00:58–01:10 · Hỗ trợ quan sát. Phản hồi có trách nhiệm.

Camera trong trình duyệt
Theo dõi dấu hiệu té ngã · Phản hồi trên giao diện
Email cần dịch vụ được cấu hình · Nguyên mẫu học tập
Không phải thiết bị y tế

Lời dẫn đề xuất: Không dự đoán té ngã trước sự kiện; không chẩn đoán và không tự gọi cấp cứu. Chưa kiểm thử email; mạng và backend là điều kiện cần.

Nguồn: Bài gốc 3 · Tài liệu góp ý 4

## 4. 01:10–01:24 · Từ hình ảnh đến phản hồi

Camera · MediaPipe
33 điểm mốc · Đặc trưng
Fall Score · Máy trạng thái · Cảnh báo
Phản hồi

Lời dẫn đề xuất: Sơ đồ khái niệm: nhận tư thế, tính đặc trưng và xét diễn biến theo thời gian. MediaPipe không tự trả kết luận ngã.

Nguồn: Bài gốc 4 · Tài liệu góp ý 5

## 5. 01:24–01:39 · Nhìn thấy điều hệ thống đang thấy

01 Camera / mô phỏng · 02 Khung xương · 03 ID theo dõi tạm thời · 04 Fall Score: điểm 0–1 · 05 Trạng thái hiện tại

Lời dẫn đề xuất: Ảnh được cung cấp là DEMO SIM. ID không phải danh tính sinh trắc. Phần trăm trên giao diện là cách hiển thị điểm, không phải xác suất hoặc độ chính xác.

Nguồn: assets/live-monitor.jpg · Ảnh tham chiếu, không phải thử nghiệm trực tiếp

## 6. 01:39–01:54 · Một cơ hội để phản hồi

FALLEN → mở hộp thoại
Đếm ngược 15 giây theo góp ý · “Tôi ổn” → hủy
Hoặc chọn gửi ngay · Hết hạn → thử gửi email
Cần cấu hình và kết nối mạng

Lời dẫn đề xuất: Tài liệu góp ý 7 nói modal mở ngay từ FALLEN; engine đồng thời tích lũy bất động để chuyển ALERT. Không phải hai chu kỳ 15 giây nối tiếp. Chưa có source app để kiểm tra, chưa thử gửi email.

Nguồn: Tài liệu góp ý 7, ghi chú — chưa xác minh mã nguồn hiện tại

## 7. 01:54–02:08 · 33 điểm mốc. Một đầu vào, chưa phải kết luận.

Vai 11 / 12 · Hông 23 / 24 · Gối 25 / 26 · Cổ chân 27 / 28 · Visibility ≠ Fall Score

Lời dẫn đề xuất: Sơ đồ nguyên bản chỉ minh họa các khớp chính; không phải toàn bộ 33 điểm. Tọa độ chuẩn hóa không phải đơn vị cm.

Nguồn: Google AI Edge · Pose Landmarker · Bài gốc 7

## 8. 02:08–02:22 · Thiếu dữ liệu không có nghĩa là an toàn

NO_PERSON
Chưa có tư thế hợp lệ · PARTIAL_POSE
Dữ liệu thân chưa đủ tin cậy · ID tạm thời
Có thể đổi khi mất dấu

Lời dẫn đề xuất: Theo góp ý, canEvaluateFall = reliableTorso && (hasLowerJoint || (torsoCount === 4 && completeness >= .40)). Không khẳng định luôn bắt buộc thấy chân. Công thức chưa kiểm tra trên source app.

Nguồn: Tài liệu góp ý 9, ghi chú · Nguồn ứng dụng chưa được cung cấp

## 9. 02:22–02:36 · Nằm ngang chỉ là một dấu hiệu

W = xmax − xmin
H = ymax − ymin · r = W/H · r < 0,75: dọc
r > 1,30: ngang · Tọa độ chuẩn hóa
Cần kết hợp chuyển động

Lời dẫn đề xuất: Các ngưỡng dẫn theo góp ý 10, chưa xác minh mã hiện tại. Nhãn ngang khác điểm horizontalScore = clamp((r-.9)/.8,0,1). Người chủ động nằm xuống cũng có thể có khung ngang.

Nguồn: Tài liệu góp ý 10 · Ngưỡng tham khảo, chưa xác minh source

## 10. 02:36–02:53 · Bảy tín hiệu. Một điểm tổng hợp.

FallScore = clamp(mROI × Σ wi si) · Tổng trọng số = 1,00 · 0,68 không phải xác suất ngã 68%

Lời dẫn đề xuất: Bảy trọng số khớp bài gốc và góp ý nhưng chưa đối chiếu source hiện tại. Ground contact chỉ đếm điểm gần đáy ảnh; không chứng minh chạm sàn. Nếu có classifier, điểm cuối có thể khác ruleScore; chưa xác minh chế độ.

Nguồn: Bài gốc 9 · Tài liệu góp ý 11

## 11. 02:53–03:10 · 0,521 — cách cộng điểm, không phải độ chính xác

Giả sử mROI = 1 · Chưa dùng model hỗ trợ · Còn xét hình học và thời gian

Lời dẫn đề xuất: Điểm thành phần [.75,.50,.60,0,.50,.60,.50]; tích trọng số [.165,.100,.108,0,.060,.048,.040], tổng .521. Đây là số giả định của tài liệu góp ý, không phải dữ liệu đo.

Nguồn: Tài liệu góp ý 12 · Ví dụ giả định, không phải kết quả kiểm thử

## 12. 03:10–03:28 · Một điểm số chưa đủ xác nhận ngã

STANDING · PRE_FALL · FALLEN · ALERT

Lời dẫn đề xuất: Theo góp ý: STANDING→PRE_FALL khi hạ nhanh và nghiêng thân hoặc score≥.45 tích lũy đủ 3 bước, với cổng người/thân hợp lệ. PRE_FALL→FALLEN: ngang đủ 4 bước hoặc score≥.68 và góc>60° hoặc giảm chiều cao nhanh kèm ≥2 điểm gần đáy. FALLEN→ALERT sau bất động tích lũy 15s. Modal đã mở từ FALLEN. Bộ đếm bước khác giây; cần xác minh code hiện tại.

Nguồn: Tài liệu góp ý 13–14 · Điều kiện rút gọn, chưa xác minh source

## 13. 03:28–03:44 · Minh bạch để tiến xa hơn

Đã có: giao diện DEMO SIM
Chưa đo hiệu quả trên dữ liệu thực · Tiếp theo: kiểm thử có kiểm soát
Đứng, cúi, thiếu điểm, ngã mô phỏng · Giới hạn: sáng, che khuất, góc máy
Quyền camera và mạng gửi email

Lời dẫn đề xuất: Không yêu cầu người cao tuổi ngã thật. Các kịch bản là kế hoạch kiểm thử, chưa thực hiện. Ghi log phát hiện đúng, bỏ sót, báo sai và trạng thái email; không suy ra độ chính xác lâm sàng từ test phần mềm.

Nguồn: Tài liệu góp ý 16 · Không có số đo thực nghiệm trong bộ đính kèm
