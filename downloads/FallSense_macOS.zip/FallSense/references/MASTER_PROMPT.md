# FALLSENSE — MASTER PRODUCTION PROMPT FOR CODEX

## ROLE AND DELIVERABLE
You are a principal creative director, senior 3D motion designer, technical presentation designer, Remotion/React/TypeScript engineer, and factual academic editor. Build a complete, **runnable** FallSense cinematic opening followed seamlessly by an animated academic presentation. Do not stop after proposing an idea or generating static mockups. Deliver a functioning Remotion project, rendered MP4 (if feasible), storyboard, shot list, reusable components, source/asset attribution and QA report. Use Vietnamese for presentation text; keep established English product labels where they match the app.

**INPUTS**: `assets/overview.jpg`, `assets/live-monitor.jpg`, `assets/training.jpg`, `assets/incidents.jpg`, `assets/settings.jpg`; `references/GIOI_THIEU_NGANH_Nhom06_13slide.pptx` and `references/nhung_j_can_sua.pptx` if present. Additional source app folder, audio, mascot `.glb`, fonts, or logos may be provided later. Inspect actual files before coding. Source app is READ-ONLY. Images are references; prefer freshly captured screenshots if available. Some screenshots may include private contact data: never expose emails, names, secrets, or account details; mask them in all rendered scenes.

## GOAL / CREATIVE LANGUAGE
'FallSense — A Little Guardian': a premium, gentle, cheerful, Apple-keynote-inspired **original** visual language. Not a clone of Apple branding. Friendly 3D chibi mascot inspired by the app's pink shield mark, with a rounded marshmallow-like silhouette, tiny arms, expressive eyes, blush cheeks, soft subsurface-like shading. 3D mascot appears, gestures, reveals FallSense wordmark, introduces actual web UI through an elegant carousel of floating browser surfaces, then guides into an academic slide deck without a hard cut. Overall cute but mature, polished, spacious, and scientifically credible. Use real product UI as the main hero, not fictional dashboards.

### Brand tokens
- ice-blue background `#EAF7FB`, blush pink `#F2D8E8`, lavender `#E9DDF8`, white `#F8F9FC`, magenta accent `#C44C99`, dark typography `#20212A`, sage status `#4F8D61`.
- Use diffuse studio lighting, ambient shadows, realistic edge highlights, occasional translucent glass; NO black sci-fi backgrounds, intense neon, strobing, generic AI imagery, confetti overload.
- Font: choose licensed font with complete Vietnamese glyphs (e.g. Be Vietnam Pro from Google Fonts) and embed/localize it for deterministic rendering.
- Minimum legible body text 30 px on 1920x1080; limit each academic slide to a few short visual groups; detail belongs in speaker notes / narration script.

## TECHNICAL ARCHITECTURE
- Remotion + React + TypeScript, 1920x1080, 60 FPS, H.264 MP4, 16:9.
- Create separate compositions: `FallSenseIntro` (~43s), `FallSensePresentation` (slides; pacing adjustable), `FallSenseFullShow` (intro+presentation), and optionally `FallSenseTeaser` (30s). Duration must be derived from config, not mismatched hardcoded frame counts.
- Use Remotion `Sequence`, `TransitionSeries` where appropriate, `useCurrentFrame`, `interpolate`, `spring`, `staticFile`, media components; avoid non-deterministic CSS animations, `Date.now()`, random without seed, browser-only autoplay, and non-frame-synchronized audio.
- For true 3D chibi, prefer React Three Fiber + `@remotion/three` where supported and verified; fallback to carefully layered 2.5D if 3D render fails. If no `.glb` exists, model an original simple procedural chibi from primitives, not a flat emoji. Implement subtle idle bounce, blinking, pointing, and waving via deterministic frame-based motion. Render/test headless Chromium compatibility.
- Use perspective/3D transforms for actual screenshot panels; readable text must be front-facing at hero frames. Add shadows and screen reflections but do not obscure UI.
- Keep 3D rendering performant on Apple Silicon; preview at reduced scale, final render at full resolution. Lazy-load expensive scenes only if compatible with Remotion's rendering semantics.
- Create components: `Mascot3D`, `StudioStage`, `SoftLight`, `LogoReveal`, `BrowserFrame`, `WebCarousel`, `FeatureKeyword`, `PoseLandmarkDiagram`, `AcademicSlide`, `KpiCard`, `StateMachineDiagram`, `TimelineBar`, `SourceFootnote`, `AudioTimeline`, `PresentationConfig`.
- Implement user-editable `config.ts` (colors, text, feature list, screenshots, durations, music/audio track, narrator track, mute, slide timings). Keep all asset paths relative to `public/`.
- Export a separate subtitle/narration script with timestamps; provide optional `.srt`. A provided audio file must be inspected for duration, format, sample rate and actual speech content before syncing. DO NOT pretend speech transcription is available unless a transcription tool was actually run. Use manual transcript input when unavailable.

## OPENING STORYBOARD — TARGET ~43 SECONDS
**Scene 01 (00:00–00:06) / HELLO GUARDIAN:** Camera glides across ice-blue/white gradient cyclorama. A pink 3D shield-chibi gently drops into frame, lands with spring and waves. Tiny floating sparkles; elegant soft 'pop' sound. Text optional: 'Một người bạn nhỏ.'
**Scene 02 (00:06–00:12) / BRAND REVEAL:** Mascot taps a floating glass shield; logo forms from rotating layers; large wordmark `FallSense` assembles smoothly. Subtitle `Hệ thống hỗ trợ giám sát và cảnh báo té ngã bằng camera`. Optional marketing line `A Little Guardian. A Safer Tomorrow.` clearly identified as a slogan, not a clinical promise.
**Scene 03 (00:12–00:21) / WEB HERO:** Shield opens like a portal, morphing into a realistic floating browser window. Use the REAL `overview.jpg` interface. Browser rotates from 12–16 degrees perspective toward the camera, stops readable. Highlight cards using subtle magnification and callouts: `Camera`, `Giám sát`, `Trạng thái` (avoid claiming camera is active in screenshot, which explicitly says not started).
**Scene 04 (00:21–00:37) / FEATURE CAROUSEL:** Horizontal 2.5D/3D slider with screen panels moving past a virtual camera in depth, with subtle parallax and focus. `live-monitor.jpg`: `Live Monitor`, `Khung xương`, `Fall Score`; `training.jpg`: `AI Training Lab`, `Phân tích video`, `Gắn nhãn`; `incidents.jpg`: `Incidents`, `Lịch sử sự cố`; `settings.jpg`: `Settings`, `Người nhận cảnh báo`, `Ngôn ngữ`. Do not show private email fields. Each card receives 3–4 sec; motion easing no jerky stops. Screens must remain recognizable. The live monitor is clearly marked `DEMO SIM`; do not imply real clinical validation.
**Scene 05 (00:37–00:43) / SEAMLESS HANDOFF:** Four browser panels arc around mascot and fold into a translucent pink shield. Shield blooms into a pastel-white transition. The first academic title slide emerges in the SAME spatial layout. Hold title for at least 2 sec. No black cut, no duplicate intro title afterward.

## ACADEMIC PRESENTATION AFTER THE OPENING
Build an **editable 13-slide target** based on the actual original 10-slide PPTX and correction PPTX. Do not assume filename '13slide' contains 13 slides. Do not show the correction guide itself as presentation slides. Extract exact factual content and speaker notes before implementing; preserve source notes and distinguish original vs proposed changes. Content order should progress from motivation to interface, then technical method, then demo/limitations. Suggested 13-slide structure:
1. **Title**: `Giới thiệu ngành Công nghệ thông tin`; `FallSense — Hệ thống hỗ trợ giám sát và cảnh báo té ngã bằng camera`; `Nhóm 06 – IE005.R11.CNVN`; `TS. Nguyễn Tấn Hoàng Phước`; `Trường Đại học Công nghệ Thông tin – ĐHQG-HCM`.
2. **Bối cảnh và vấn đề**: WHO 2021 estimate 684,000 fall deaths annually globally, clearly year-qualified; Fleming & Brayne 2008: among 66 fallers aged >90, 53/66 (~80%) could not get up unaided after at least one fall, 20/66 (~30%) were on the floor >=1h. These are study-specific proportions, NOT population estimates. Add citations small but legible. Flag potential updated WHO data for editorial decision rather than silently changing it.
3. **Mục tiêu & phạm vi**: browser-based camera monitoring, signs of falling, on-screen feedback, configured email channel if operational; educational prototype, not a medical device or diagnosis.
4. **Nguyên lý hoạt động**: `Camera → MediaPipe landmarks → Đặc trưng chuyển động / Fall Score → Máy trạng thái → Cảnh báo / Phản hồi`; animated flow with one moving token at a time.
5. **Giao diện thật & cách sử dụng**: use `live-monitor.jpg`; animate 5 real callouts: camera/simulation view, pose skeleton, temporary person ID, Fall Score, state. Explicitly say Fall Score 0–1 is a rule-based aggregate score, not probability or accuracy.
6. **Cảnh báo & phản hồi**: source correction says modal countdown 15s opens when FALLEN is confirmed; `Tôi ổn` cancels; after countdown / send-now, email is attempted via configured service. DO NOT claim automatic emergency calls or two consecutive 15s waiting periods. This requires verification against current live source app.
7. **MediaPipe Pose**: 33 landmarks; highlight shoulders 11/12, hips 23/24, knees 25/26, ankles 27/28. Landmarks provide pose inputs, NOT an out-of-box fall verdict. Render original pose schematic with simple 2D SVG (no copied copyrighted graphics).
8. **Input quality & tracking**: NO_PERSON, PARTIAL_POSE and reliable torso, visibility checks, person ID as temporary tracker ID, not biometric identity. Distinguish insufficient data from safe status.
9. **Bounding box orientation (new)**: `W=xmax−xmin`, `H=ymax−ymin`, `r=W/H`; proposed slide notes vertical <0.75, horizontal >1.30 in normalized coordinates. Explain horizontal body box is one feature, not proof of a fall. Confirm thresholds against current source before presenting as implemented.
10. **Fall Score**: 7 weighted features from original slide (vertical speed .22, torso angle .20, height reduction .18, head below hips .12, horizontal posture .12, sustained vertical speed .08, landmarks near image bottom .08). Visualize as 7 proportional bars, sum 1.00; DO NOT call score a probability. Confirm names/weights against source.
11. **Illustrative worked Fall Score example (new)**: use correction deck's explicit hypothetical example and label `Ví dụ giả định`; do not claim measured test accuracy. Recheck arithmetic and source before rendering.
12. **State machine**: NO_PERSON / PARTIAL_POSE / STANDING / PRE_FALL / FALLEN / ALERT; conditions must reflect current code and correction notes. Show time vs frame-step distinctions. Avoid oversimplifying score thresholds as sufficient by themselves.
13. **Demo, giới hạn và kết luận (new)**: safe controlled demo of normal standing, bending/sitting, partial pose, simulated fall, cancel alert/email verification; label each `Mô phỏng` or `Đã kiểm thử` only if evidence exists. Show limitations (lighting, occlusion, false alerts, browser/camera permissions, network-dependent email). No invented accuracy/sensitivity/latency metrics.

**Slide motion language**: one elegant continuous visual grammar; flowing connector lines, morphing cards, 3D UI surfaces, icon-to-diagram transformations, chart reveals; animation duration ~0.3–0.8s; never hold a transition for many seconds. Avoid text-heavy slides; max 3–5 primary visual elements per slide. Build speaker notes/narration separately, and visible small citations on data slides. Slides should pause/advance through config or render to a predetermined timeline. Provide a presenter-friendly MP4 and optionally a separately editable PPTX only if technically feasible; Remotion MP4 is NOT inherently editable PowerPoint.

## SCIENTIFIC AND PRIVACY QA — HARD GATES
- Product: FallSense, NOT stroke diagnosis or fall prediction before the event.
- Educational prototype; no clinical safety/accuracy claims without measured evidence.
- Distinguish `DEMO SIM` from real camera output.
- Distinguish a landmark visibility/confidence score from Fall Score.
- Distinguish `FALLEN` and `ALERT`; inspect actual app source before claiming precise timing.
- `Email alert` requires configured working network/service; don't claim email delivered unless tested.
- Screenshot settings contains personally identifying email; mask/redact before output.
- Original PPTX and correction PPTX may conflict. Produce `CONTENT_AUDIT.md` with conflict, preferred wording, evidence/source, verification status. Never silently overwrite uncertain content.
- Source/attribution footnotes must remain readable; preserve DOI/URLs in `SOURCES.md`.

## AUDIO WORKFLOW
Initially render without narration, with royalty-cleared placeholder SFX if available. When user supplies an audio file: inspect actual metadata; if voiceover, obtain reliable transcript with timestamps (ask for transcript if no tool is available); derive cue points; set audio gain, fade, duck music under voice; synchronize slides by cues and re-render. If music, detect/mark beats only after inspecting actual audio. Never make up beat timestamps or words. Keep `music`, `voiceover`, `sfx` as separate tracks. Output a silent preview and a final audio-mixed MP4. Honor supplied soundtrack licensing.

## FREE TEMPLATES / VERIFIED REFERENCES (DO NOT BLINDLY COPY)
- Remotion official free templates: https://www.remotion.dev/templates
- Remotion 3D React Three Fiber starter: listed on https://www.remotion.dev/templates
- Remotion community resources: https://www.remotion.dev/docs/resources
- RenderComp 50 MIT templates: https://github.com/RenderComp/free-remotion-templates (retain license header/notice)
- React Video Editor free Remotion templates: https://github.com/reactvideoeditor/remotion-templates (check license per template)
- Mixkit free sound effects: https://mixkit.co/free-sound-effects/ (check each asset's license)
- LottieFiles: https://lottiefiles.com/ (free animation license and platform plan terms may differ; verify before commercial use)
- Google MediaPipe documentation: https://developers.google.com/edge/mediapipe/solutions/vision/pose_landmarker
- WHO Falls: https://www.who.int/news-room/fact-sheets/detail/falls
- Fleming & Brayne (2008): https://www.bmj.com/content/337/bmj.a2227
Templates are inspiration and source code components, not automatically bundled video assets. Document URLs, license and usage in `THIRD_PARTY_ASSETS.md`. Do not download anything behind a paywall or assume all resources are free for commercial reuse.

## PHASED EXECUTION (MUST COMPLETE EACH PHASE)
1. `INVENTORY`: list actual source files, image dimensions, PPTX slide counts, missing audio/mascot assets, and app-source availability. Never pretend screenshots prove behavior.
2. `CONTENT AUDIT`: extract PPTX content and notes, produce 13-slide mapping and conflict table; ask only for genuinely blocking choices.
3. `STORYBOARD`: make a precise timecoded shot list and animation plan; show which real UI asset each scene uses.
4. `PROJECT`: install dependencies and create fully typed working Remotion compositions; ensure proper file paths and composition registration.
5. `CHARACTER`: create original chibi in 3D or 2.5D fallback; test 5 representative frames.
6. `WEB FLOW`: implement cinematic browser UI panels, slide/carousel, keywords and focus pulls.
7. `PRESENTATION`: build 13 animated academic slides using content audit and verified labels.
8. `AUDIO`: prepare cue sheet, accept supplied audio later, synchronize and export.
9. `QA`: render representative still frames at 0s, 6s, 12s, 20s, 30s, 42s, and every slide start/end; check clipping, readable text, timing, privacy, image resolution, scientific claims.
10. `DELIVER`: `out/FallSense_Intro.mp4`, `out/FallSense_FullShow.mp4`, optionally `out/FallSense_SilentPreview.mp4`, project source, `README.md`, `CONTENT_AUDIT.md`, `SOURCES.md`, `THIRD_PARTY_ASSETS.md`, `NARRATION_SCRIPT.md`, and render commands. If rendering fails, report exact command/error and leave a working preview; do not claim files were rendered.

## FINAL ACCEPTANCE CRITERIA
- Original pastel identity matches screenshots; genuine UI legible and not replaced by invented mockups.
- Original cute shield chibi visibly appears and gestures in the opening.
- FallSense logo reveal → floating Overview → feature carousel → academic title slide is ONE coherent continuous motion sequence.
- Academic presentation covers source-backed content with proposed 13-slide corrections and explicit sources.
- No exposed email addresses or sensitive identifiers.
- At least one successfully rendered video or an explicit reproducible error log.
- No unverified claims of performance, diagnosis, or emergency dispatch.

Start by auditing the provided files and creating a concrete implementation plan, then proceed to actual code. Do not merely answer with suggestions.
