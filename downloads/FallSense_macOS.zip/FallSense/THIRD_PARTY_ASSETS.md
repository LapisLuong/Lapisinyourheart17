# Assets và quyền sử dụng

| Tài sản | Nguồn | Sử dụng / giấy phép |
|---|---|---|
| 5 JPG giao diện | Gói người dùng cung cấp | Dùng cho trình chiếu được yêu cầu; quyền tái phân phối công khai chưa được xác nhận |
| Hai PPTX | Gói người dùng cung cấp | Trích text/notes để audit, không sao chép hình nghiên cứu |
| Nhạc từ MP4 65s bổ sung | Người dùng cung cấp, yêu cầu dùng cho intro | Tách AAC nguyên bản, không dùng phần hình TikTok; quyền tái phân phối/công khai chưa xác minh |
| MP4 15s | Người dùng cung cấp | Chỉ kiểm tra tham chiếu; không nhúng vào output, không có audio |
| Noto Sans Regular/Bold | Font cài trong hệ thống, Google Noto | SIL Open Font License; bản quyền kèm `public/fonts/LICENSE` |
| Mascot, pose diagram, đồ họa | Tạo nguyên bản bằng SVG/React trong dự án | Không dùng mẫu tải ngoài |
| Remotion 4.0.373 | npm / remotion.dev | Phần mềm có điều khoản Remotion; kiểm tra https://www.remotion.dev/license trước khi dùng thương mại/ở tổ chức |
| React / TypeScript | npm | MIT / Apache-2.0; giữ license trong dependency |

Không tải nhạc/SFX hoặc template từ nguồn ngoài. Soundtrack hiện có là file do người dùng cung cấp; không tuyên bố đây là nhạc miễn phí hoặc đã được cấp phép thương mại.
