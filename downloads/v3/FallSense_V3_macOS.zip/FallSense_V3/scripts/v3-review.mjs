import { bundle } from "@remotion/bundler";
import {
  selectComposition,
  renderStill,
  openBrowser,
} from "@remotion/renderer";
import { resolveBrowser } from "./browser.mjs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
const serveUrl = await bundle({ entryPoint: "src/v3/index.tsx" });
const browserExecutable = resolveBrowser();
const browser = await openBrowser("chrome", {
  browserExecutable,
  chromiumOptions: { gl: "swangle" },
});
try {
  const composition = await selectComposition({
    serveUrl,
    id: "FallSenseCinematicIntroV3",
    puppeteerInstance: browser,
  });
  const shots = JSON.parse(await readFile("beat-map.json", "utf8")).shots;
  const stress = [20, 350, 1012, 2118, 2579];
  const frames = process.argv.includes("--stress")
    ? [...stress, 193, 678, 693, 694, 1988, 1989]
    : [
        ...new Set([
          ...stress,
          ...shots.map((s) =>
            Math.min(
              s.endFrame - 1,
              s.startFrame + Math.round((s.endFrame - s.startFrame) * 0.65),
            ),
          ),
        ]),
      ].sort((a, b) => a - b);
  await mkdir("out/v3/frames", { recursive: true });
  for (const frame of frames) {
    const begin = performance.now();
    await renderStill({
      serveUrl,
      composition,
      puppeteerInstance: browser,
      frame,
      output: `out/v3/frames/${String(frame).padStart(5, "0")}.jpg`,
      imageFormat: "jpeg",
      scale: 0.5,
    });
    console.log(
      `V3 still ${frame} (${((performance.now() - begin) / 1000).toFixed(1)}s)`,
    );
  }
  await writeFile(
    process.argv.includes("--stress")
      ? "out/v3/stress-manifest.json"
      : "out/v3/review-manifest.json",
    JSON.stringify(
      { frames, composition: composition.id, stress, scale: 0.5 },
      null,
      2,
    ),
  );
} finally {
  await browser.close({ silent: true });
}
