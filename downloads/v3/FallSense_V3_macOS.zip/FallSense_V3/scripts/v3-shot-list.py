import json
from pathlib import Path
m=json.loads(Path('beat-map.json').read_text());rows=[]
for n,s in enumerate(m['shots'],1):
 i=s['id']
 axis=('Macro / close-up; grazing highlights and bevel parallax' if i<=3 or i in [7,8,11,28] else '3/4 mascot; intentional turn / gesture' if i<=10 or i==30 else 'Continuous five-plane scene; camera dolly / settle' if i<=26 else 'Spatial pose → pupil / shield arc' if i<=29 else 'Negative-space brand / quiet title hold')
 fov=43 if i==1 else 44 if i in [3,7] else 37 if i in [4,6,30] else 38 if i in [13,15,20,22,24,26] else 39 if i in [8,17,18,19,21,23,25] else 42 if i==29 else 40
 asset='Original extruded shield mesh / satin, pearl inset' if i<=11 or i in [28,30,31,32] else 'overview.jpg' if i<=17 else 'live-monitor.jpg' if i<=20 else 'training.jpg' if i<=22 else 'incidents.jpg' if i<=24 else 'settings.jpg + opaque privacy mask' if i<=26 else 'Original cylinder/sphere landmark diagram + real UI planes'
 cut='Measured transient / action continuity'
 if i==11:cut='Shield bevel→screen edge graphic alignment, then camera retreat'
 if i==12:cut='Screen edge takes over the previous shield-edge axis; rapid push-out'
 if i==27:cut='Camera follows a landmark sphere; accelerates into a round feature'
 if i==28:cut='Landmark circle→right pupil, same screen center and approximate diameter'
 if i==32:cut='Quiet resolution; exact factual title held to end'
 path='Quadratic Bézier arc + cubic ease-out' if i in [4,9,16,18,21,23,25] else 'Eased camera position / target; no realtime clock'
 copy='QUAN SÁT.' if i in [4,6] else 'FallSense' if i in [10,31] else 'NHẬN BIẾT.' if i in [16,27] else 'CẢNH BÁO.' if i==29 else 'Exact factual title' if i==32 else 'Only authentic UI page labels / demo qualification' if 12<=i<=26 else 'None'
 marker=f"{s['transientSeconds']:.4f}s, strength {s['onsetStrength']}" if s['transientSeconds'] is not None else 'Intentional start (not claimed beat)'
 rows.append(f"| {n:02d} / {i} | {s['inSeconds']:.3f}–{s['outSeconds']:.3f} | {s['name']} | {cut} | {axis}; FOV {fov}°; {path} | {copy} | {marker} | {asset}; mesh thickness, adjacent planes and occlusion; music only, no uncleared SFX |")
Path('V3_SHOT_LIST.md').write_text('# V3 — final 30-shot edit decision list\n\n43s / 2580 frames / 60fps. Stable source IDs retain gaps after removing two redundant shots; the first column numbers the actual final 30 shots. Audio analysis is measured spectral onset detection, not a human-certified musical beat annotation. Every aligned cut is quantized to a 60fps frame within 8.34ms of its selected signal transient. Selected directional-blur ramps appear only during motivated travel in shots 12/16/23. UI planes share a continuous 3D layout; readable hero holds settle at each page.\n\n| Shot / source ID | IN–OUT (s) | Intent | Cut motivation | Lens / axis / camera path | Copy | Audio marker | Foreground/background/asset/SFX |\n|---|---|---|---|---|---|---|---|\n'+'\n'.join(rows)+'\n')
