"""Offline spectral-flux transient analysis; measured tempo, not assumed BPM."""
import json,subprocess
from pathlib import Path
import numpy as np
sr=22050;hop=256;window=1024
raw=subprocess.check_output(['ffmpeg','-v','error','-i','public/audio/user-supplied.m4a','-t','43','-ac','1','-ar',str(sr),'-f','f32le','-'])
x=np.frombuffer(raw,dtype='<f4');frames=np.lib.stride_tricks.sliding_window_view(x,window)[::hop]
mag=np.abs(np.fft.rfft(frames*np.hanning(window),axis=1));freq=np.fft.rfftfreq(window,1/sr)
mag=mag[:,(freq>=70)&(freq<=8000)];mag=np.log1p(mag*10)
flux=np.maximum(0,np.diff(mag,axis=0)).mean(axis=1);flux=np.r_[0,flux]
flux=(flux-np.median(flux))/(np.std(flux)+1e-9)
times=(np.arange(len(flux))*hop+window/2)/sr
peaks=[]
for i in range(2,len(flux)-2):
 if flux[i]>max(.5,np.median(flux[max(0,i-40):i+41])+.6) and flux[i]>=max(flux[i-2:i+3]):
  if peaks and times[i]-peaks[-1]['seconds']<.16:
   if flux[i]>peaks[-1]['strength']:peaks[-1]={'seconds':float(times[i]),'strength':float(flux[i])}
  else:peaks.append({'seconds':float(times[i]),'strength':float(flux[i])})
y=np.maximum(flux,0);ac=np.correlate(y,y,'full')[len(y)-1:];lags=np.arange(int(sr/hop*60/170),int(sr/hop*60/75));lag=int(lags[np.argmax(ac[lags])]);bpm=60*sr/(hop*lag)
targets=[0,.65,1.25,2.2,3.6,4.9,5.6,6.8,8.15,9.6,10.8,11.5,12.8,14.1,15.1,16.7,17.8,19.2,20.5,21.8,23.2,24.6,25.9,27.4,28.8,30.4,31.7,33.1,34.6,36.1,37.8,39.3]
names=['Satin edge / macro','Rim travel','Eyes / extreme close','Guardian arrival','Confident turn','Gesture anticipation','Hand / action cut','Shield profile','Fragments / assemble','FallSense wordmark','Shield edge / graphic match','Portal / corner match','Overview / dive','Camera detail','Overview / readable hero','Gallery ignition','Overview / runway','Live Monitor / arrival','Pose line detail','Live Monitor / readable hero','AI Training Lab / dolly','Training / readable hero','Incidents / turn','Incidents / readable hero','Settings / orbit','Settings / readable hero','Landmark / spatial thread','Eye-circle match','UI / shield arc','Guardian / proud hero','FallSense / resolve','Academic handoff']
shots=[]
for i,t in enumerate(targets):
 possible=[p for p in peaks if abs(p['seconds']-t)<=.28 and (not shots or p['seconds']-shots[-1]['startFrame']/60>=.35)]
 selected=max(possible,key=lambda p:p['strength']-.8*abs(p['seconds']-t)) if possible and i else None
 f=round((selected['seconds'] if selected else t)*60)
 shots.append({'id':i+1,'name':names[i],'startFrame':f,'transientSeconds':round(selected['seconds'],4) if selected else None,'onsetStrength':round(selected['strength'],3) if selected else None,'motivation':'Measured spectral transient; validated local-maximum / spacing' if selected else 'Intentional opening / phrase hold; not a claimed beat'})
shots=[s for s in shots if s['id'] not in [5,14]]
for i,s in enumerate(shots):s['endFrame']=shots[i+1]['startFrame'] if i+1<len(shots) else 2580;s['inSeconds']=s['startFrame']/60;s['outSeconds']=s['endFrame']/60
result={'track':'audio/user-supplied.m4a','analysisSeconds':43,'sampleRate':sr,'hop':hop,'window':window,'method':'positive log-spectral flux, local maxima, 160ms refractory; quantized at 60fps','estimatedPulseBpm':round(bpm,2),'tempoCaveat':'Autocorrelation estimate may be half/double time; not manually listened or a certified musical downbeat grid. Edits use detected transients, not an assumed BPM.','peaks':peaks,'shots':shots}
Path('src/v3').mkdir(exist_ok=True)
Path('src/v3/beat-map.json').write_text(json.dumps(result,indent=2))
Path('beat-map.json').write_text(json.dumps(result,indent=2))
print('Estimated pulse BPM',round(bpm,2),'detected transients',len(peaks),'shots',len(shots),'aligned',sum(s['transientSeconds'] is not None for s in shots))
for s in shots:print(s['id'],round(s['inSeconds'],3),s['name'])
