#!/bin/bash
cd "$(dirname "$0")"
/usr/bin/open -a "QuickTime Player" "Videos/FallSense_Cinematic_Intro_FINAL.mp4"
