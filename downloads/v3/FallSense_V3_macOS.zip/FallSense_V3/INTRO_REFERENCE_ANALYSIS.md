# V3 reference study — before implementation

All network requests listed in `references/v3/reference-access.json` returned proxy **403 Forbidden**. No Apple or YouTube film was played or downloaded. No exact film URLs/publishers could be independently verified. The requested two Apple-published film inspections are **NOT WATCHED / NOT COMPLETED**, rather than invented. These are access limitations, not evidence of permission to bypass the network policy. Implementation proceeds as the brief requests.

| Source | Inspection / segment observations | Cut rate / lens / material / transitions | Adaptation proposed; what not to copy |
|---|---|---|---|
| https://www.apple.com/newsroom/2024/09/apple-debuts-iphone-16-pro-and-iphone-16-pro-max/ | NOT WATCHED; page inaccessible | Not measured | Original macro-to-hero hierarchy, not Apple objects or trade dress |
| https://developer.apple.com/design/human-interface-guidelines/motion | NOT READ; inaccessible | No observation asserted | Purposeful anticipation/action/settle; avoid gratuitous bounce |
| https://developer.apple.com/design/human-interface-guidelines/design-principles | NOT READ | Not applicable | Clear negative space and readable Vietnamese, original identity |
| https://developer.apple.com/design/human-interface-guidelines/immersive-experiences | NOT READ | Not applicable | Spatial consistency; no claim of matching source guidance |
| https://developer.apple.com/videos/play/wwdc2023/10078/ | NOT WATCHED | No timestamps or camera observations asserted | Controlled motion, not constant disorienting camera movement |
| https://www.youtube.com/@Apple/videos | NOT WATCHED; catalogue inaccessible | Could not select/verify two exact product films | No ripped footage, music, logos or frame reconstruction |

The proposed directions above are our creative decisions, not observations of inaccessible films. Original FallSense images, palette and supplied soundtrack are the actual reviewed inputs.

## Technical references

Remotion ThreeCanvas, audio visualization, flickering and encoding pages were also blocked (URLs/status recorded). Instead inspected the installed **@remotion/three 4.0.373** README, TypeScript declarations and ThreeCanvas implementation: exact Remotion version alignment, Suspense integration, context propagation, demand render/invalidation per frame, explicit canvas width/height. Three and R3F installed from npm with lockfile integrity verification. Additional requested documentation links are retained below as uninspected references, not claimed as studied:

- https://www.remotion.dev/docs/transitioning
- https://www.remotion.dev/docs/components
- https://www.remotion.dev/docs/render
- https://threejs.org/examples/
- https://r3f.docs.pmnd.rs/
- https://docs.blender.org/manual/en/latest/

## Film-specific direction

30 final editorial decisions, 29 snapped to independently detected local log-spectral-flux maxima in the supplied 43s excerpt. The measured pulse estimate is 107.67 BPM; this may be half/double time. These are verified signal transients, not claimed human-annotated downbeats. Macro satin bevel, eye close-up, decisive turn, fragment assembly, readable wordmark, corner-to-shield match, continuous five-plane runway, pose-line thread, pupil-circle match, shield arc, and a quiet final handoff. Two redundant angles were removed from the initial 32-shot plan to honor the revised 22–30-shot target. See `V3_SHOT_LIST.md` for actual lens/path and occlusion decisions.
