# FallSense Cinematic Intro V3 — opening only

One 43-second film, composition `FallSenseCinematicIntroV3`, 1920×1080 / 60 FPS. No app, backend, classifier or deck changes are part of V3.

## Open / render

Node.js 22/24 LTS. Mac: double-click `macOS/v3/Open_V3.command` or `Render_V3.command`; if Finder does not launch a command, use `bash macOS/v3/Open_V3.command` in Terminal from the project root. Windows/Linux can use the shell commands below. Watching the final MP4 requires no Node installation.

```sh
npm ci
npx remotion studio src/v3/index.tsx
npm run typecheck
node scripts/v3-review.mjs --stress
node scripts/v3-render.mjs --proof
npm run render:v3
```

Output: `out/FallSense_Cinematic_Intro_FINAL.mp4`. Final uses H.264 CRF17, yuv420p / BT.709, AAC music. The render script uses software `swangle` by default because it is verified in this cloud environment. On a Mac with supported hardware, `V3_GL=angle` can select hardware rendering; this has not been verified here. `CHROME_PATH` selects a local browser; otherwise platform paths/Remotion's download are used. Set `V3_CONCURRENCY=1` if resources are limited; normal tested target is 2 workers.

## Edit

- `src/v3/config.ts`: palette, short copy, soundtrack/gain/fades, fallback switch.
- `src/v3/beat-map.json`: authoritative editable shot start/end frames, IDs and measured onset assignments. `beat-map.json` at root is the exported analysis copy.
- `src/v3/Scene.tsx`: original extruded shield mesh, eye/limb rig, studio lights, 3D UI planes, pose metaphor and camera paths.
- `src/v3/Intro.tsx`: frame-synchronized film, kinetic type, directional composited blur and music.
- `src/v3/Fallback.tsx`: explicitly 2.5D opt-in preview fallback. Primary/final uses genuine Three geometry, not this switch.
- `V3_SHOT_LIST.md`: final 30-shot EDL, measured accent timestamps, path/lens/copy/asset notes.

There is no realtime `useFrame` animation, random sampling or physics simulation. Camera arcs use QuadraticBezierCurve3; poses, blinks, anticipation and squash/stretch depend only on the frame. No physical DOF or motion-blur integration is claimed: blur is a brief directional SVG composite on three motivated moves. Render has no video footage from Apple or TikTok; only user-supplied FallSense JPGs and the extracted soundtrack are used.

## Assets / rights / limitations

Mascot, line/sphere pose motif and transitions are original procedural graphics. Noto Sans is bundled with its OFL license. React/Three/R3F/Remotion retain their own package licenses; see Remotion's license terms for organizational/commercial use. JPGs and soundtrack came from the user. The user requested this soundtrack for the intro; public/commercial music clearance has not been verified. No uncleared SFX were added.

Source audio is 64.993s AAC stereo 44.1kHz; use its first 43s at gain .4, 1.2s fade-in / 3s fade-out. Timing is based on measured spectral transients (29 aligned edits), not a claimed human-verified downbeat grid or an assumed BPM. No speech transcript or instrumental-only claim is made.

UI is actual supplied imagery. Settings contact fields are masked in scene space. Live Monitor is labeled DEMO SIM; Overview explicitly says the camera in the image is not started. Pose geometry is labeled illustrative. No performance, medical, guaranteed safety or automatic emergency-call claims.

Apple/YouTube sources were blocked by the proxy, NOT WATCHED. Existing original compositions remain available in the main repository; this standalone delivery contains only the opening source and assets. Native macOS 27 playback/render has not been tested.
