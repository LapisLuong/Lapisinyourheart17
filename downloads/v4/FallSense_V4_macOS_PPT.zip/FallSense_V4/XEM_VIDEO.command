#!/bin/bash
cd "$(dirname "$0")"
/usr/bin/open -a "QuickTime Player" "Videos/FallSense_Cinematic_Intro_V4_Smooth3D_1080p60.mp4"
